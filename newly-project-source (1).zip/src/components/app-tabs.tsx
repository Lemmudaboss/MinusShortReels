import { NativeTabs } from 'expo-router/unstable-native-tabs';
import { useThemeColor } from 'heroui-native';

// `disableAutomaticContentInsets` on EVERY Trigger: the screens' safe-area classes are the one
// inset mechanism; without it expo-router adds a second inset on top (double gaps).
export default function AppTabs() {
  const accent = useThemeColor('accent');
  const background = useThemeColor('background');
  return (
    <NativeTabs backgroundColor={background} tintColor={accent}>
      <NativeTabs.Trigger name="index" disableAutomaticContentInsets>
        <NativeTabs.Trigger.Label>Home</NativeTabs.Trigger.Label>
        <NativeTabs.Trigger.Icon sf="house.fill" md="home" />
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="stats" disableAutomaticContentInsets>
        <NativeTabs.Trigger.Label>Stats</NativeTabs.Trigger.Label>
        <NativeTabs.Trigger.Icon sf="chart.bar.fill" md="bar_chart" />
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="rules" disableAutomaticContentInsets>
        <NativeTabs.Trigger.Label>Rules</NativeTabs.Trigger.Label>
        <NativeTabs.Trigger.Icon sf="shield.lefthalf.filled" md="shield" />
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="activity" disableAutomaticContentInsets>
        <NativeTabs.Trigger.Label>Activity</NativeTabs.Trigger.Label>
        <NativeTabs.Trigger.Icon sf="bolt.fill" md="bolt" />
      </NativeTabs.Trigger>
    </NativeTabs>
  );
}
