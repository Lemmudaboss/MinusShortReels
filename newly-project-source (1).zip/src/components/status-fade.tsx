import { LinearGradient } from 'expo-linear-gradient';
import { StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { FocusColors } from '@/constants/theme';

/** Fades scrolled content out under the status bar so the clock stays readable. */
export function StatusFade() {
  const { top } = useSafeAreaInsets();
  return (
    <LinearGradient
      pointerEvents="none"
      colors={[FocusColors.night, `${FocusColors.night}00`]}
      locations={[0.55, 1]}
      style={[styles.fade, { height: top + 14 }]}
    />
  );
}

const styles = StyleSheet.create({
  fade: { position: 'absolute', top: 0, left: 0, right: 0 },
});
