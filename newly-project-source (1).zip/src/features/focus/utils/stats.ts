import type { ActivityEvent, BlockEvent, PlatformKey, SessionEvent } from '@/features/focus/types/focus';
import { addDays, dayKey, startOfDay, startOfWeek } from '@/features/focus/utils/dates';

function blocks(events: ActivityEvent[]): BlockEvent[] {
  return events.filter((e): e is BlockEvent => e.kind === 'block');
}

function sessions(events: ActivityEvent[]): SessionEvent[] {
  return events.filter((e): e is SessionEvent => e.kind === 'session');
}

function inRange<T extends ActivityEvent>(list: T[], from: number, to: number): T[] {
  return list.filter((e) => e.at >= from && e.at < to);
}

export function savedBetween(events: ActivityEvent[], from: number, to: number, platform?: PlatformKey): number {
  return inRange(blocks(events), from, to)
    .filter((e) => (platform ? e.platform === platform : true))
    .reduce((sum, e) => sum + e.minutes, 0);
}

export function videosBetween(events: ActivityEvent[], from: number, to: number): number {
  return inRange(blocks(events), from, to).reduce((sum, e) => sum + e.videos, 0);
}

export function blockCountBetween(events: ActivityEvent[], from: number, to: number): number {
  return inRange(blocks(events), from, to).length;
}

export function focusedBetween(events: ActivityEvent[], from: number, to: number): number {
  return inRange(sessions(events), from, to).reduce((sum, e) => sum + e.minutes, 0);
}

export function savedForDay(events: ActivityEvent[], day: number, platform?: PlatformKey): number {
  return savedBetween(events, startOfDay(day), addDays(day, 1), platform);
}

/** Minutes saved per hour of a day (24 values). */
export function hourlySaved(events: ActivityEvent[], day: number): number[] {
  const start = startOfDay(day);
  const hours = Array.from({ length: 24 }, () => 0);
  inRange(blocks(events), start, addDays(day, 1)).forEach((e) => {
    hours[new Date(e.at).getHours()] += e.minutes;
  });
  return hours;
}

/** Minutes saved for each day Mon–Sun of the week containing `day`. */
export function weekSaved(events: ActivityEvent[], day: number): number[] {
  const monday = startOfWeek(day);
  return Array.from({ length: 7 }, (_, i) => savedForDay(events, addDays(monday, i)));
}

export function avoidedCounts(events: ActivityEvent[], from: number, to: number) {
  const list = inRange(blocks(events), from, to);
  const count = (keys: PlatformKey[]) =>
    list.filter((e) => keys.includes(e.platform)).reduce((s, e) => s + e.videos, 0);
  return {
    youtube: count(['youtube']),
    instagram: count(['instagram']),
    tiktok: count(['tiktok']),
    other: count(['x', 'reddit', 'other']),
  };
}

/** Days in a row (ending today or yesterday) with at least one focus session. */
export function streakInfo(events: ActivityEvent[], now: number): { current: number; longest: number } {
  const days = new Set(sessions(events).map((e) => dayKey(e.at)));
  let cursor = startOfDay(now);
  if (!days.has(dayKey(cursor))) cursor = addDays(cursor, -1);
  let current = 0;
  while (days.has(dayKey(cursor))) {
    current += 1;
    cursor = addDays(cursor, -1);
  }
  const sorted = [...days].sort();
  let longest = 0;
  let run = 0;
  let prev = '';
  sorted.forEach((key) => {
    const prevDay = prev ? dayKey(addDays(new Date(`${prev}T12:00:00`).getTime(), 1)) : '';
    run = prevDay === key ? run + 1 : 1;
    longest = Math.max(longest, run);
    prev = key;
  });
  return { current, longest: Math.max(longest, current) };
}

/** Focus score for a day: focus time, distractions avoided and tasks finished. */
export function scoreForDay(events: ActivityEvent[], day: number, tasksDone: number): number {
  const from = startOfDay(day);
  const to = addDays(day, 1);
  const focused = focusedBetween(events, from, to);
  const saved = savedBetween(events, from, to);
  const raw = 38 + Math.min(30, focused * 0.4) + Math.min(22, saved * 0.12) + tasksDone * 2.5;
  return Math.max(0, Math.min(100, Math.round(raw)));
}

export function scoreLabel(score: number): string {
  if (score >= 85) return 'Excellent focus today';
  if (score >= 70) return 'Strong focus today';
  if (score >= 50) return 'Building momentum';
  return 'A fresh start';
}

export function signed(value: string, raw: number): string {
  return raw >= 0 ? `+${value}` : `−${value}`;
}
