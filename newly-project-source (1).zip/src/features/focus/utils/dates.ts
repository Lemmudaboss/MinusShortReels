export const DAY_MS = 24 * 60 * 60 * 1000;

export function dayKey(ms: number): string {
  const d = new Date(ms);
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

export function startOfDay(ms: number): number {
  const d = new Date(ms);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

/** Monday 00:00 of the week containing ms. */
export function startOfWeek(ms: number): number {
  const d = new Date(startOfDay(ms));
  const offset = (d.getDay() + 6) % 7;
  return startOfDay(d.getTime() - offset * DAY_MS + 2 * 60 * 60 * 1000);
}

export function addDays(ms: number, days: number): number {
  return startOfDay(ms + days * DAY_MS + 2 * 60 * 60 * 1000);
}

/** "1h 48m", "42m", "0m". */
export function formatMinutes(total: number): string {
  const mins = Math.max(0, Math.round(total));
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (h === 0) return `${m}m`;
  return `${h}h ${m}m`;
}

/** Minutes after midnight → "9:00 AM". */
export function formatClock(minutes: number): string {
  const h24 = Math.floor(minutes / 60) % 24;
  const m = minutes % 60;
  const suffix = h24 >= 12 ? 'PM' : 'AM';
  const h12 = h24 % 12 === 0 ? 12 : h24 % 12;
  return `${h12}:${String(m).padStart(2, '0')} ${suffix}`;
}

export function formatTime(ms: number): string {
  const d = new Date(ms);
  return formatClock(d.getHours() * 60 + d.getMinutes());
}

/** "2:14 PM", "Yesterday, 9:03 PM", "Apr 24, 1:11 PM". */
export function formatWhen(ms: number, now: number): string {
  const today = startOfDay(now);
  if (ms >= today) return formatTime(ms);
  if (ms >= addDays(today, -1)) return `Yesterday, ${formatTime(ms)}`;
  const d = new Date(ms);
  const month = d.toLocaleString('en-US', { month: 'short' });
  return `${month} ${d.getDate()}, ${formatTime(ms)}`;
}

export function formatDayLabel(ms: number, now: number): string {
  const d = new Date(ms);
  const month = d.toLocaleString('en-US', { month: 'short' });
  const base = `${month} ${d.getDate()}`;
  if (startOfDay(ms) === startOfDay(now)) return `Today, ${base}`;
  if (startOfDay(ms) === addDays(startOfDay(now), -1)) return `Yesterday, ${base}`;
  return `${d.toLocaleString('en-US', { weekday: 'short' })}, ${base}`;
}

export const WEEKDAY_SHORT = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

/** days use JS getDay(): 0 = Sun … 6 = Sat. */
export function formatDays(days: number[]): string {
  const sorted = [...days].sort((a, b) => a - b);
  if (sorted.length === 7) return 'Every day';
  if (sorted.join(',') === '1,2,3,4,5') return 'Mon – Fri';
  if (sorted.join(',') === '0,6') return 'Weekends';
  const names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  return sorted.map((d) => names[d]).join(', ');
}
