import { dayKey, formatMinutes, formatTime } from '@/features/focus/utils/dates';

export const LOCK_OPTIONS = [
  { minutes: 30, label: '30 min' },
  { minutes: 60, label: '1 hour' },
  { minutes: 120, label: '2 hours' },
  { minutes: 240, label: '4 hours' },
  { minutes: 480, label: '8 hours' },
  { minutes: 1440, label: '24 hours' },
] as const;

/** "4:15 PM", or "tomorrow, 4:15 PM" when it ends on another day. */
export function lockEndLabel(until: number, now: number): string {
  if (dayKey(until) === dayKey(now)) return formatTime(until);
  return `tomorrow, ${formatTime(until)}`;
}

/** "1h 12m left"; under a minute reads "under 1m left". */
export function lockLeft(until: number, now: number): string {
  const minutes = Math.ceil((until - now) / 60000);
  if (minutes < 1) return 'under 1m left';
  return `${formatMinutes(minutes)} left`;
}
