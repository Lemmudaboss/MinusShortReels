import type { ActivityEvent, PlatformKey, Schedule, Site, Task } from '@/features/focus/types/focus';
import { addDays, dayKey, startOfDay } from '@/features/focus/utils/dates';

function rng(seed: number) {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

const TITLES: Record<PlatformKey, string> = {
  youtube: 'YouTube Shorts blocked',
  instagram: 'Instagram Reels blocked',
  tiktok: 'TikTok blocked',
  x: 'X (Twitter) blocked',
  reddit: 'reddit.com blocked',
  other: 'Short video blocked',
};

const SESSION_NAMES = ['Deep Work Session', 'Morning Focus', 'Project Work'];

/** A believable two weeks of blocks, sessions and streak milestones, ending now. */
export function seedEvents(now: number): ActivityEvent[] {
  const rand = rng(42);
  const events: ActivityEvent[] = [];
  const today = startOfDay(now);
  let id = 0;
  // More blocked as the week goes on; 13 days back to today.
  for (let back = 13; back >= 0; back -= 1) {
    const day = addDays(today, -back);
    const intensity = back <= 6 ? 1 + (6 - back) * 0.22 : 0.9;
    const count = Math.round(9 + rand() * 4);
    for (let i = 0; i < count; i += 1) {
      const hourPool = [7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 18, 19, 19, 20, 21, 22, 23];
      const hour = hourPool[Math.floor(rand() * hourPool.length)];
      const at = day + hour * 3600000 + Math.floor(rand() * 59) * 60000;
      if (at > now) continue;
      const r = rand();
      const platform: PlatformKey =
        r < 0.55 ? 'youtube' : r < 0.9 ? 'instagram' : r < 0.97 ? 'tiktok' : r < 0.985 ? 'reddit' : 'other';
      const minutes = Math.round((4 + rand() * 12) * intensity);
      events.push({
        id: `seed-b${id++}`,
        kind: 'block',
        platform,
        title: TITLES[platform],
        session: SESSION_NAMES[hour < 11 ? 1 : hour < 17 ? 0 : 2],
        at,
        minutes,
        videos: Math.max(1, Math.round(minutes / 2.4)),
      });
    }
    // Focus sessions for the last six days build the streak.
    if (back <= 5) {
      const at = day + 9 * 3600000 + 30 * 60000;
      if (at <= now) {
        events.push({ id: `seed-s${id++}`, kind: 'session', session: 'Morning Focus', at, minutes: 50, completed: true });
      }
      const at2 = day + 14 * 3600000 + 5 * 60000;
      if (at2 <= now) {
        events.push({ id: `seed-s${id++}`, kind: 'session', session: 'Deep Work Session', at: at2, minutes: 25, completed: true });
      }
      const streakDay = 6 - back;
      if (streakDay >= 2 && at <= now) {
        events.push({ id: `seed-m${id++}`, kind: 'milestone', days: streakDay, at: at + 60000 });
      }
    }
  }
  return events.sort((a, b) => b.at - a.at);
}

export function seedTasks(now: number): Task[] {
  const today = dayKey(now);
  return [
    { id: 't1', title: 'Finish design system update', start: 9 * 60, end: 11 * 60, doneOn: today },
    { id: 't2', title: 'Reply to client emails', start: 11 * 60 + 30, end: 12 * 60, doneOn: today },
    { id: 't3', title: 'Write project documentation', start: 14 * 60, end: 15 * 60 + 30, doneOn: null },
    { id: 't4', title: 'Gym workout', start: 17 * 60 + 30, end: 18 * 60 + 30, doneOn: null },
    { id: 't5', title: 'Read for 20 minutes', start: 21 * 60, end: 21 * 60 + 20, doneOn: null },
  ];
}

export const SEED_SITES: Site[] = [
  { id: 'youtube', name: 'YouTube', domain: 'youtube.com', category: 'Video & Streaming', platform: 'youtube', blocked: true },
  { id: 'instagram', name: 'Instagram', domain: 'instagram.com', category: 'Social Media', platform: 'instagram', blocked: true },
  { id: 'tiktok', name: 'TikTok', domain: 'tiktok.com', category: 'Social Media', platform: 'tiktok', blocked: true },
  { id: 'x', name: 'X (Twitter)', domain: 'x.com', category: 'Social Media', platform: 'x', blocked: true },
  { id: 'reddit', name: 'Reddit', domain: 'reddit.com', category: 'Social Media', platform: 'reddit', blocked: true },
];

export const SEED_SCHEDULES: Schedule[] = [
  { id: 'work', name: 'Work Hours', icon: 'cup', days: [1, 2, 3, 4, 5], start: 9 * 60, end: 17 * 60 },
  { id: 'evening', name: 'Evening Focus', icon: 'moon', days: [0, 1, 2, 3, 4, 5, 6], start: 21 * 60, end: 23 * 60 },
];
