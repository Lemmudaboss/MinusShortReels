export type PlatformKey = 'youtube' | 'instagram' | 'tiktok' | 'x' | 'reddit' | 'other';

export interface BlockEvent {
  id: string;
  kind: 'block';
  platform: PlatformKey;
  title: string;
  session: string;
  at: number;
  minutes: number;
  videos: number;
}

export interface SessionEvent {
  id: string;
  kind: 'session';
  session: string;
  at: number;
  minutes: number;
  completed: boolean;
}

export interface MilestoneEvent {
  id: string;
  kind: 'milestone';
  days: number;
  at: number;
}

export type ActivityEvent = BlockEvent | SessionEvent | MilestoneEvent;

export interface Task {
  id: string;
  title: string;
  start: number;
  end: number;
  doneOn: string | null;
}

export interface Site {
  id: string;
  name: string;
  domain: string;
  category: string;
  platform: PlatformKey;
  blocked: boolean;
}

export type ScheduleIcon = 'cup' | 'moon' | 'book' | 'sun';

export interface Schedule {
  id: string;
  name: string;
  icon: ScheduleIcon;
  days: number[];
  start: number;
  end: number;
}

export interface RedirectMessage {
  title: string;
  body: string;
}

export interface ActiveSession {
  name: string;
  minutes: number;
  startedAt: number;
}

export interface SessionResult {
  name: string;
  minutes: number;
  completed: boolean;
  streak: number;
  newMilestone: boolean;
}
