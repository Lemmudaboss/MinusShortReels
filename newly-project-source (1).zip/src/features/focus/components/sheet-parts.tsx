import DateTimePicker, { DateTimePickerAndroid } from '@react-native-community/datetimepicker';
import type { ReactNode } from 'react';
import { Platform, Text, TextInput, View, type TextInputProps } from 'react-native';
import { withUniwind } from 'uniwind';

import { Pressable } from '@/components/pressable';
import { usePalette } from '@/features/focus/hooks/use-palette';
import { formatClock } from '@/features/focus/utils/dates';
import { cn } from '@/lib/cn';

const StyledInput = withUniwind(TextInput);

/** The root of every bottom sheet: sized to its content, padded, in the card colour. */
export function SheetBody({ children }: { children: ReactNode }) {
  return <View className="bg-surface px-5 pt-7 pb-safe-offset-4 gap-5">{children}</View>;
}

export function SheetTitle({ title, subtitle, left }: { title: string; subtitle?: string; left?: ReactNode }) {
  return (
    <View className="flex-row items-center gap-3">
      {left ?? null}
      <View className="flex-1 gap-0.5">
        <Text className="text-xl font-semibold text-foreground">{title}</Text>
        {subtitle ? <Text className="text-xs text-muted">{subtitle}</Text> : null}
      </View>
    </View>
  );
}

export function FieldLabel({ children }: { children: string }) {
  return <Text className="text-[10px] font-semibold tracking-widest text-muted">{children}</Text>;
}

interface FieldProps extends Omit<TextInputProps, 'className'> {
  label: string;
}

export function Field({ label, ...input }: FieldProps) {
  const palette = usePalette();
  return (
    <View className="gap-2">
      <FieldLabel>{label}</FieldLabel>
      <StyledInput
        {...input}
        placeholderTextColor={palette.muted}
        selectionColor={palette.accent}
        keyboardAppearance="dark"
        className={cn(
          'rounded-xl border border-border bg-surface-secondary px-4 text-sm text-foreground',
          input.multiline ? 'min-h-20 py-3' : 'h-12 leading-none',
        )}
      />
    </View>
  );
}

export function Chip({ label, on, onPress }: { label: string; on: boolean; onPress: () => void }) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected: on }}
      onPress={onPress}
      className={cn('rounded-full border px-3.5 py-2', on ? 'border-accent bg-iris-deep' : 'border-border bg-surface-secondary')}>
      <Text className={cn('text-xs font-medium', on ? 'text-foreground' : 'text-muted')}>{label}</Text>
    </Pressable>
  );
}

export function PrimaryButton({ label, onPress, disabled }: { label: string; onPress: () => void; disabled?: boolean }) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: !!disabled }}
      isDisabled={disabled}
      onPress={onPress}
      className={cn('items-center justify-center rounded-full bg-accent py-3.5', disabled ? 'opacity-40' : '')}>
      <Text className="text-base font-semibold text-accent-foreground">{label}</Text>
    </Pressable>
  );
}

export function SecondaryButton({ label, onPress, danger }: { label: string; onPress: () => void; danger?: boolean }) {
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      className="items-center justify-center rounded-full border border-border bg-surface-secondary py-3.5">
      <Text className={cn('text-base font-semibold', danger ? 'text-ember' : 'text-lilac')}>{label}</Text>
    </Pressable>
  );
}

function toDate(minutes: number): Date {
  const d = new Date();
  d.setHours(Math.floor(minutes / 60), minutes % 60, 0, 0);
  return d;
}

/** A time of day (minutes after midnight): the compact native picker on iOS, the clock dialog on Android. */
export function TimeField({ label, value, onChange }: { label: string; value: number; onChange: (m: number) => void }) {
  const palette = usePalette();
  const apply = (d?: Date) => {
    if (!d) return;
    onChange(d.getHours() * 60 + d.getMinutes());
  };
  return (
    <View className="flex-1 gap-2">
      <FieldLabel>{label}</FieldLabel>
      {Platform.OS === 'ios' ? (
        <View className="h-12 flex-row items-center rounded-xl border border-border bg-surface-secondary px-2">
          <DateTimePicker
            value={toDate(value)}
            mode="time"
            display="compact"
            themeVariant="dark"
            accentColor={palette.accent}
            onChange={(_, d) => apply(d)}
          />
        </View>
      ) : (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`${label}, ${formatClock(value)}`}
          onPress={() =>
            DateTimePickerAndroid.open({ value: toDate(value), mode: 'time', onChange: (_, d) => apply(d) })
          }
          className="h-12 justify-center rounded-xl border border-border bg-surface-secondary px-4">
          <Text className="text-sm text-foreground">{formatClock(value)}</Text>
        </Pressable>
      )}
    </View>
  );
}
