import { View } from 'react-native';

export function Divider({ inset = false }: { inset?: boolean }) {
  return (
    <View className={inset ? 'pl-11' : ''}>
      <View className="h-px bg-border" />
    </View>
  );
}
