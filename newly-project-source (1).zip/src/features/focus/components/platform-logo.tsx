import { View } from 'react-native';

import { Image } from '@/components/image';
import { Glyph } from '@/features/focus/components/glyph';
import { usePalette } from '@/features/focus/hooks/use-palette';
import type { PlatformKey } from '@/features/focus/types/focus';
import { cn } from '@/lib/cn';

const LOGOS = {
  youtube: require('@/assets/images/art/logo-youtube.png'),
  instagram: require('@/assets/images/art/logo-instagram.png'),
  tiktok: require('@/assets/images/art/logo-tiktok.png'),
  x: require('@/assets/images/art/logo-x.png'),
  reddit: require('@/assets/images/art/logo-reddit.png'),
};

interface PlatformLogoProps {
  platform: PlatformKey;
  size?: 'sm' | 'md';
}

export function PlatformLogo({ platform, size = 'md' }: PlatformLogoProps) {
  const palette = usePalette();
  const box = size === 'md' ? 'size-9' : 'size-7';
  if (platform === 'other') {
    return (
      <View className={cn(box, 'items-center justify-center rounded-xl bg-iris-deep')}>
        <Glyph name={{ ios: 'safari', android: 'explore' }} size={size === 'md' ? 20 : 16} color={palette.lilac} />
      </View>
    );
  }
  return <Image source={LOGOS[platform]} className={box} contentFit="contain" />;
}
