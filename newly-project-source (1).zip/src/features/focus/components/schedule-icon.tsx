import type { SymbolViewProps } from 'expo-symbols';
import { View } from 'react-native';

import { Glyph } from '@/features/focus/components/glyph';
import { usePalette } from '@/features/focus/hooks/use-palette';
import type { ScheduleIcon as ScheduleIconKey } from '@/features/focus/types/focus';

export const SCHEDULE_ICONS: Record<ScheduleIconKey, SymbolViewProps['name']> = {
  cup: { ios: 'cup.and.saucer.fill', android: 'coffee' },
  moon: { ios: 'moon.fill', android: 'dark_mode' },
  book: { ios: 'book.fill', android: 'menu_book' },
  sun: { ios: 'sun.max.fill', android: 'light_mode' },
};

export function ScheduleIcon({ icon }: { icon: ScheduleIconKey }) {
  const palette = usePalette();
  return (
    <View className="size-9 items-center justify-center rounded-xl bg-surface-secondary">
      <Glyph name={SCHEDULE_ICONS[icon]} size={17} color={palette.lilac} />
    </View>
  );
}
