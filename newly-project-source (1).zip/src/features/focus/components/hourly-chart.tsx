import { Canvas, DashPathEffect, Line, LinearGradient, RoundedRect, vec } from '@shopify/react-native-skia';
import { useState } from 'react';
import { Text, View } from 'react-native';

import { usePalette } from '@/features/focus/hooks/use-palette';

interface HourlyChartProps {
  values: number[];
  labels: string[];
  height?: number;
}

/** 24 (or 7) violet bars over a dashed 0 / 30m / 60m grid, drawn in Skia. */
export function HourlyChart({ values, labels, height = 96 }: HourlyChartProps) {
  const palette = usePalette();
  const [width, setWidth] = useState(0);
  const axis = 28;
  const plotW = Math.max(0, width - axis);
  const top = Math.max(60, ...values);
  const gap = values.length > 12 ? 2 : 8;
  const barW = values.length ? Math.max(2, (plotW - gap * (values.length - 1)) / values.length) : 0;
  const ticks = [top, top / 2, 0];

  return (
    <View className="flex-1 gap-1">
      <View style={{ height }} onLayout={(e) => setWidth(e.nativeEvent.layout.width)}>
        <Canvas style={{ width, height }}>
          {ticks.map((t) => {
            const y = height - (t / top) * (height - 6) - 1;
            return (
              <Line key={t} p1={vec(0, y)} p2={vec(plotW, y)} color={palette.border} strokeWidth={1}>
                <DashPathEffect intervals={[3, 3]} />
              </Line>
            );
          })}
          {values.map((v, i) => {
            const h = Math.max(2, (v / top) * (height - 6));
            const x = i * (barW + gap);
            return (
              <RoundedRect key={i} x={x} y={height - h} width={barW} height={h} r={Math.min(3, barW / 2)}>
                <LinearGradient start={vec(0, height - h)} end={vec(0, height)} colors={[palette.lilac, palette.accent]} />
              </RoundedRect>
            );
          })}
        </Canvas>
        <View className="absolute right-0 top-0 bottom-0 justify-between" pointerEvents="none">
          {ticks.map((t) => (
            <Text key={t} className="text-[9px] text-muted">
              {Math.round(t)}m
            </Text>
          ))}
        </View>
      </View>
      <View className="flex-row justify-between" style={{ width: plotW }}>
        {labels.map((l) => (
          <Text key={l} className="text-[9px] text-muted">
            {l}
          </Text>
        ))}
      </View>
    </View>
  );
}
