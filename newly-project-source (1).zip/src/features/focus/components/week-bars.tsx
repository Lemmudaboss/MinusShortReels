import { LinearGradient } from 'expo-linear-gradient';
import { Text, View } from 'react-native';

import { usePalette } from '@/features/focus/hooks/use-palette';
import { WEEKDAY_SHORT } from '@/features/focus/utils/dates';
import { cn } from '@/lib/cn';

interface WeekBarsProps {
  values: number[];
  height: number;
  highlight: number;
  showValues?: boolean;
  barWidth?: number;
  compact?: boolean;
}

/** Mon–Sun bars, the brightest one is today (or the selected day). */
export function WeekBars({ values, height, highlight, showValues, barWidth = 18, compact }: WeekBarsProps) {
  const palette = usePalette();
  const max = Math.max(60, ...values);
  return (
    <View className="flex-1 flex-row items-end gap-0.5">
      {values.map((v, i) => {
        const h = Math.max(6, (v / max) * height);
        const lit = i === highlight;
        return (
          <View key={WEEKDAY_SHORT[i]} className="min-w-0 flex-1 items-center gap-1">
            {showValues ? (
              <Text numberOfLines={1} className={cn(compact ? 'text-[9px] tracking-tighter' : 'text-[10px]', 'text-muted')}>{v > 0 ? `${(v / 60).toFixed(1)}h` : '–'}</Text>
            ) : null}
            <LinearGradient
              colors={lit ? [palette.lilac, palette.accent] : [palette.accent, palette.iris]}
              style={{ width: '80%', maxWidth: barWidth, height: h, borderRadius: 4, opacity: lit || showValues ? 1 : 0.75 }}
            />
            <Text numberOfLines={1} className={cn('text-[10px]', lit ? 'text-foreground' : 'text-muted')}>{compact ? WEEKDAY_SHORT[i].charAt(0) : WEEKDAY_SHORT[i]}</Text>
          </View>
        );
      })}
    </View>
  );
}
