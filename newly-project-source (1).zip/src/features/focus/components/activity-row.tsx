import { Text, View } from 'react-native';

import { ListRow } from '@/components/list-row';
import { Glyph } from '@/features/focus/components/glyph';
import { IconTile } from '@/features/focus/components/icon-tile';
import { PlatformLogo } from '@/features/focus/components/platform-logo';
import { usePalette } from '@/features/focus/hooks/use-palette';
import type { ActivityEvent } from '@/features/focus/types/focus';
import { formatWhen } from '@/features/focus/utils/dates';

export function eventTitle(e: ActivityEvent): string {
  if (e.kind === 'block') return e.title;
  if (e.kind === 'session') return e.completed ? `${e.session} complete` : `${e.session} ended early`;
  return `${e.days} day streak milestone`;
}

export function eventSubtitle(e: ActivityEvent, compact?: boolean): string {
  if (e.kind === 'block') {
    return compact ? `${e.minutes}m · ${e.videos} videos` : `Focus session • ${e.session}`;
  }
  if (e.kind === 'session') return `${e.minutes} min focused`;
  return e.days >= 5 ? `You've focused ${e.days} days in a row!` : "You're on a roll!";
}

interface ActivityRowProps {
  event: ActivityEvent;
  now: number;
  compact?: boolean;
  onPress: () => void;
}

export function ActivityRow({ event, now, compact, onPress }: ActivityRowProps) {
  const palette = usePalette();
  const left =
    event.kind === 'block' ? (
      <PlatformLogo platform={event.platform} />
    ) : (
      <IconTile tone="soft" name={event.kind === 'milestone' ? { ios: 'flame.fill', android: 'local_fire_department' } : { ios: 'timer', android: 'timer' }} size="md" />
    );
  const right = (
    <View className="items-end gap-1">
      <Text className="text-[11px] text-muted">{formatWhen(event.at, now)}</Text>
      {event.kind === 'block' && !compact ? (
        <View className="flex-row items-center gap-1">
          <Glyph name={{ ios: 'nosign', android: 'block' }} size={11} color={palette.lilac} />
          <Text className="text-[11px] text-lilac">{event.minutes} min prevented</Text>
        </View>
      ) : null}
    </View>
  );
  return (
    <ListRow
      title={eventTitle(event)}
      subtitle={eventSubtitle(event, compact)}
      left={left}
      right={right}
      onPress={onPress}
    />
  );
}
