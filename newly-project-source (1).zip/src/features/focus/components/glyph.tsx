import { SymbolView, type SymbolViewProps } from 'expo-symbols';

interface GlyphProps {
  name: SymbolViewProps['name'];
  size?: number;
  color: string;
  weight?: SymbolViewProps['weight'];
}

/** An SF Symbol on iOS, the matching Material Symbol on Android. */
export function Glyph({ name, size = 18, color, weight = 'medium' }: GlyphProps) {
  return <SymbolView name={name} size={size} tintColor={color} weight={weight} />;
}
