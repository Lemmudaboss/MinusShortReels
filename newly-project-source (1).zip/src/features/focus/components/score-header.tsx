import { Text, View } from 'react-native';

import { Pressable } from '@/components/pressable';
import { Glow } from '@/features/focus/components/glow';
import { Glyph } from '@/features/focus/components/glyph';
import { ScoreRing } from '@/features/focus/components/score-ring';
import { usePalette } from '@/features/focus/hooks/use-palette';

interface ScoreHeaderProps {
  score: number;
  delta: number;
  label: string;
  onInfo: () => void;
}

/** The Focus Score ring and its caption at the top of Home. */
export function ScoreHeader({ score, delta, label, onInfo }: ScoreHeaderProps) {
  const palette = usePalette();
  const up = delta >= 0;
  return (
    <View className="flex-row items-center gap-5 py-2">
      <View className="items-center justify-center">
        <View className="absolute">
          <Glow size={190} opacity={0.4} />
        </View>
        <ScoreRing size={92} stroke={7} progress={score / 100}>
          <Text className="text-3xl font-bold text-foreground">{score}</Text>
          <Text className="text-[10px] text-muted">/100</Text>
        </ScoreRing>
      </View>
      <View className="flex-1 gap-1">
        <Pressable accessibilityRole="button" accessibilityLabel="About Focus Score" onPress={onInfo} className="flex-row items-center gap-2 self-start">
          <Text className="text-base font-semibold text-foreground">Focus Score</Text>
          <Glyph name={{ ios: 'info.circle', android: 'info' }} size={15} color={palette.muted} />
        </Pressable>
        <View className="flex-row items-center gap-2">
          <Text className="text-xs text-lilac">{label}</Text>
          <Glyph
            name={up ? { ios: 'arrow.up.right', android: 'north_east' } : { ios: 'arrow.down.right', android: 'south_east' }}
            size={11}
            color={palette.lilac}
          />
          <Text className="text-xs font-semibold text-lilac">{`${up ? '+' : '−'}${Math.abs(delta)}`}</Text>
        </View>
      </View>
    </View>
  );
}
