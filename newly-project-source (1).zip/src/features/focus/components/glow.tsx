import { Canvas, Circle, RadialGradient, vec } from '@shopify/react-native-skia';
import { View } from 'react-native';

import { usePalette } from '@/features/focus/hooks/use-palette';

interface GlowProps {
  size: number;
  opacity?: number;
}

/** A soft violet bloom behind the mascot and the score ring. */
export function Glow({ size, opacity = 0.45 }: GlowProps) {
  const palette = usePalette();
  const c = size / 2;
  return (
    <View pointerEvents="none" style={{ width: size, height: size, opacity }}>
      <Canvas style={{ width: size, height: size }}>
        <Circle cx={c} cy={c} r={c}>
          <RadialGradient c={vec(c, c)} r={c} colors={[palette.accent, `${palette.accent}00`]} />
        </Circle>
      </Canvas>
    </View>
  );
}
