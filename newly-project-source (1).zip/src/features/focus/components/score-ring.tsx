import { Canvas, Path, Skia, SweepGradient, vec } from '@shopify/react-native-skia';
import { useEffect, type ReactNode } from 'react';
import { View } from 'react-native';
import { useSharedValue, withTiming } from 'react-native-reanimated';

import { usePalette } from '@/features/focus/hooks/use-palette';
import { timing } from '@/lib/motion';

interface ScoreRingProps {
  size: number;
  stroke: number;
  progress: number;
  children?: ReactNode;
  /** Draw in from empty on mount (score), or follow the value tween-free (a live timer). */
  animate?: boolean;
}

/** The violet progress ring: a dim track with a gradient arc drawn over it in Skia. */
export function ScoreRing({ size, stroke, progress, children, animate = true }: ScoreRingProps) {
  const palette = usePalette();
  const end = useSharedValue(animate ? 0 : progress);

  useEffect(() => {
    if (!animate) {
      end.set(progress);
      return;
    }
    end.set(withTiming(Math.max(0.001, progress), timing.draw));
  }, [progress, animate, end]);

  const r = (size - stroke) / 2;
  const path = Skia.Path.Make();
  path.addCircle(size / 2, size / 2, r);
  const c = size / 2;

  return (
    <View style={{ width: size, height: size }} className="items-center justify-center">
      <Canvas style={{ position: 'absolute', width: size, height: size, transform: [{ rotate: '-90deg' }] }}>
        <Path path={path} style="stroke" strokeWidth={stroke} color={palette.iris} />
        <Path path={path} style="stroke" strokeWidth={stroke} strokeCap="round" start={0} end={end}>
          <SweepGradient c={vec(c, c)} colors={[palette.accent, palette.lilac, palette.accent]} />
        </Path>
      </Canvas>
      {children}
    </View>
  );
}
