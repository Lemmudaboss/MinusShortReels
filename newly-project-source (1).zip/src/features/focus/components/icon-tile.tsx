import type { SymbolViewProps } from 'expo-symbols';
import { View } from 'react-native';

import { Glyph } from '@/features/focus/components/glyph';
import { usePalette } from '@/features/focus/hooks/use-palette';
import { cn } from '@/lib/cn';

interface IconTileProps {
  name: SymbolViewProps['name'];
  size?: 'sm' | 'md';
  tone?: 'solid' | 'soft';
}

/** The violet rounded square that heads each card in the design. */
export function IconTile({ name, size = 'md', tone = 'solid' }: IconTileProps) {
  const palette = usePalette();
  return (
    <View
      className={cn(
        'items-center justify-center rounded-xl',
        size === 'md' ? 'size-10' : 'size-8 rounded-lg',
        tone === 'solid' ? 'bg-accent' : 'bg-iris-deep',
      )}>
      <Glyph name={name} size={size === 'md' ? 20 : 16} color={tone === 'solid' ? palette.foreground : palette.lilac} />
    </View>
  );
}
