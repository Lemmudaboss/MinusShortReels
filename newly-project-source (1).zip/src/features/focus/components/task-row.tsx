import { useEffect } from 'react';
import { Text, View } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withSequence, withTiming } from 'react-native-reanimated';
import { Presets } from 'react-native-pulsar';

import { ListRow } from '@/components/list-row';
import { Pressable } from '@/components/pressable';
import { Glyph } from '@/features/focus/components/glyph';
import { usePalette } from '@/features/focus/hooks/use-palette';
import type { Task } from '@/features/focus/types/focus';
import { formatClock } from '@/features/focus/utils/dates';
import { timing } from '@/lib/motion';

interface TaskRowProps {
  task: Task;
  done: boolean;
  onToggle: () => void;
  onOpen: () => void;
}

/** A task with its tick circle: ticking fills the circle with iris and pops the check in. */
export function TaskRow({ task, done, onToggle, onOpen }: TaskRowProps) {
  const palette = usePalette();
  const fill = useSharedValue(done ? 1 : 0);
  const pop = useSharedValue(1);

  useEffect(() => {
    fill.set(withTiming(done ? 1 : 0, timing.enter));
  }, [done, fill]);

  const fillStyle = useAnimatedStyle(() => ({ opacity: fill.get(), transform: [{ scale: 0.4 + fill.get() * 0.6 }] }));
  const ringStyle = useAnimatedStyle(() => ({ transform: [{ scale: pop.get() }] }));

  const check = (
    <Pressable
      accessibilityRole="checkbox"
      accessibilityState={{ checked: done }}
      accessibilityLabel={`Mark ${task.title} ${done ? 'not done' : 'done'}`}
      hitSlop={8}
      onPress={() => {
        if (!done) {
          Presets.System.notificationSuccess();
          pop.set(withSequence(withTiming(1.18, timing.exit), withTiming(1, timing.enter)));
        }
        onToggle();
      }}>
      <Animated.View style={ringStyle} className="size-8 items-center justify-center rounded-full border-2 border-night-line">
        <Animated.View style={fillStyle} className="absolute size-8 items-center justify-center rounded-full bg-accent">
          <Glyph name={{ ios: 'checkmark', android: 'check' }} size={14} weight="bold" color={palette.foreground} />
        </Animated.View>
      </Animated.View>
    </Pressable>
  );

  return (
    <View className={done ? 'opacity-90' : undefined}>
      <ListRow
        title={task.title}
        subtitle={`${formatClock(task.start)} – ${formatClock(task.end)}`}
        left={check}
        onPress={onOpen}
      />
    </View>
  );
}

export function TasksCount({ done, total }: { done: number; total: number }) {
  return <Text className="text-sm text-muted">{`${done}/${total}`}</Text>;
}
