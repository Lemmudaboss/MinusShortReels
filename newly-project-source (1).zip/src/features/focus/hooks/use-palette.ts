import { useCSSVariable } from 'uniwind';

import { FocusColors } from '@/constants/theme';

/** Raw token colors for native props (Skia, symbols, icons) that can't take a className. */
export function usePalette() {
  const [accent, lilac, muted, foreground, surface, border, danger, iris] = useCSSVariable([
    '--color-accent',
    '--color-lilac',
    '--color-muted',
    '--color-foreground',
    '--color-surface',
    '--color-night-line',
    '--color-ember',
    '--color-iris-deep',
  ]);
  return {
    accent: String(accent ?? FocusColors.accent),
    lilac: String(lilac ?? FocusColors.lilac),
    muted: String(muted ?? FocusColors.muted),
    foreground: String(foreground ?? FocusColors.foreground),
    surface: String(surface ?? FocusColors.surface),
    border: String(border ?? FocusColors.border),
    danger: String(danger ?? FocusColors.danger),
    iris: String(iris ?? FocusColors.iris),
  };
}
