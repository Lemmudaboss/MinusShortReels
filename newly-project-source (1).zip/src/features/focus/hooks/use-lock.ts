import { useNow } from '@/features/focus/hooks/use-now';
import { isLocked, useFocusStore } from '@/features/focus/store/focus-store';
import { lockLeft, lockEndLabel } from '@/features/focus/utils/lock';

/** The commitment lock as the screens show it, refreshed every 15 seconds. */
export function useLock() {
  useNow(15000);
  // The tick only re-renders; read the clock fresh so a just-started lock never shows a stale minute.
  const now = Date.now();
  const lockUntil = useFocusStore((s) => s.lockUntil);
  const locked = isLocked(lockUntil, now);
  return {
    now,
    locked,
    until: locked ? lockUntil : null,
    endLabel: locked && lockUntil !== null ? lockEndLabel(lockUntil, now) : '',
    left: locked && lockUntil !== null ? lockLeft(lockUntil, now) : '',
  };
}
