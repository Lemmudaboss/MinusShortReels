import { useState } from 'react';

import { useOverview } from '@/features/focus/hooks/use-overview';
import { addDays, formatDayLabel, startOfDay, startOfWeek } from '@/features/focus/utils/dates';
import {
  avoidedCounts,
  hourlySaved,
  savedBetween,
  savedForDay,
  videosBetween,
  weekSaved,
} from '@/features/focus/utils/stats';

export type StatsRange = 'daily' | 'weekly';

export function useStatsScreen() {
  const o = useOverview();
  const [range, setRange] = useState<StatsRange>('daily');
  const [offset, setOffset] = useState(0);

  const today = startOfDay(o.now);
  const daily = range === 'daily';
  const from = daily ? addDays(today, -offset) : addDays(startOfWeek(o.now), -7 * offset);
  const to = daily ? addDays(from, 1) : addDays(from, 7);
  const prevFrom = daily ? addDays(from, -1) : addDays(from, -7);

  const saved = savedBetween(o.events, from, to);
  const prevSaved = savedBetween(o.events, prevFrom, from);
  const videos = videosBetween(o.events, from, to);
  const prevVideos = videosBetween(o.events, prevFrom, from);

  const days = daily ? 1 : Math.max(1, Math.min(7, Math.round((Math.min(to, o.now) - from) / 86400000 + 0.5)));
  const average = Math.round(saved / days);
  const prevAverage = Math.round(prevSaved / (daily ? 1 : 7));

  const chart = daily
    ? hourlySaved(o.events, from)
    : Array.from({ length: 7 }, (_, i) => savedForDay(o.events, addDays(from, i)));

  const label = daily
    ? formatDayLabel(from, o.now)
    : offset === 0
      ? 'This week'
      : offset === 1
        ? 'Last week'
        : `Week of ${new Date(from).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`;

  return {
    ...o,
    range,
    setRange: (r: StatsRange) => {
      setRange(r);
      setOffset(0);
    },
    offset,
    older: () => setOffset(Math.min(offset + 1, daily ? 13 : 1)),
    newer: () => setOffset(Math.max(0, offset - 1)),
    canOlder: offset < (daily ? 13 : 1),
    label,
    saved,
    savedDelta: saved - prevSaved,
    vsLabel: daily ? (offset === 0 ? 'vs yesterday' : 'vs day before') : 'vs week before',
    videos,
    videosDelta: videos - prevVideos,
    average,
    averageDelta: average - prevAverage,
    chart,
    chartLabels: daily ? ['12AM', '6AM', '12PM', '6PM'] : ['Mon', 'Wed', 'Fri', 'Sun'],
    avoided: avoidedCounts(o.events, from, to),
    weekValues: weekSaved(o.events, o.now),
  };
}
