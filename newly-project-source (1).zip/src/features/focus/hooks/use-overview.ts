import { useFocusStore } from '@/features/focus/store/focus-store';
import { addDays, dayKey, startOfDay, startOfWeek } from '@/features/focus/utils/dates';
import { useNow } from '@/features/focus/hooks/use-now';
import {
  savedBetween,
  savedForDay,
  scoreForDay,
  scoreLabel,
  streakInfo,
  weekSaved,
} from '@/features/focus/utils/stats';

/** The headline numbers shared by Home, Stats and Activity. */
export function useOverview() {
  const now = useNow();
  const events = useFocusStore((s) => s.events);
  const tasks = useFocusStore((s) => s.tasks);
  const today = startOfDay(now);
  const todayKey = dayKey(now);
  const tasksDone = tasks.filter((t) => t.doneOn === todayKey).length;
  const score = scoreForDay(events, today, tasksDone);
  const yesterdayScore = scoreForDay(events, addDays(today, -1), 2);
  const weekStart = startOfWeek(now);
  const thisWeek = savedBetween(events, weekStart, now + 1);
  const lastWeekSameSpan = savedBetween(events, addDays(weekStart, -7), now - 7 * 86400000 + 1);
  const week = weekSaved(events, now);
  return {
    now,
    events,
    tasks,
    tasksDone,
    score,
    scoreDelta: score - yesterdayScore,
    label: scoreLabel(score),
    todaySaved: savedForDay(events, today),
    youtubeToday: savedForDay(events, today, 'youtube'),
    instagramToday: savedForDay(events, today, 'instagram'),
    thisWeek,
    weekDelta: thisWeek - lastWeekSameSpan,
    lastWeekSpan: lastWeekSameSpan,
    week,
    todayIndex: (new Date(now).getDay() + 6) % 7,
    streak: streakInfo(events, now),
  };
}
