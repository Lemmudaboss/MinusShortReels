import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';

import type {
  ActiveSession,
  ActivityEvent,
  RedirectMessage,
  Schedule,
  SessionResult,
  Site,
  Task,
} from '@/features/focus/types/focus';
import { dayKey } from '@/features/focus/utils/dates';
import { SEED_SCHEDULES, SEED_SITES, seedEvents, seedTasks } from '@/features/focus/utils/seed';
import { streakInfo } from '@/features/focus/utils/stats';
import { zustandStorage } from '@/lib/storage';

interface FocusState {
  blockYouTube: boolean;
  blockInstagram: boolean;
  scheduleOn: boolean;
  sites: Site[];
  schedules: Schedule[];
  message: RedirectMessage;
  tasks: Task[];
  events: ActivityEvent[];
  active: ActiveSession | null;
  lastResult: SessionResult | null;
  /** While Date.now() is before this, blocking can't be turned off or weakened. */
  lockUntil: number | null;

  setBlockYouTube: (on: boolean) => void;
  setBlockInstagram: (on: boolean) => void;
  setScheduleOn: (on: boolean) => void;
  startLock: (minutes: number) => void;

  toggleTask: (id: string) => void;
  saveTask: (task: Task) => void;
  deleteTask: (id: string) => void;

  setSiteBlocked: (id: string, blocked: boolean) => void;
  addSite: (site: Site) => void;
  deleteSite: (id: string) => void;

  saveSchedule: (schedule: Schedule) => void;
  deleteSchedule: (id: string) => void;

  setMessage: (message: RedirectMessage) => void;

  startSession: (name: string, minutes: number) => void;
  finishSession: (completed: boolean) => SessionResult | null;
  cancelSession: () => void;
}

const now = Date.now();

/** True while a commitment lock is running. */
export function isLocked(lockUntil: number | null, at = Date.now()): boolean {
  return lockUntil !== null && at < lockUntil;
}

function newID(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.floor(Math.random() * 1e6).toString(36)}`;
}

export const useFocusStore = create<FocusState>()(
  persist(
    (set, get) => ({
      blockYouTube: true,
      blockInstagram: true,
      scheduleOn: true,
      sites: SEED_SITES,
      schedules: SEED_SCHEDULES,
      message: {
        title: 'Stay on track!',
        body: 'This site is blocked so you can focus on what matters.',
      },
      tasks: seedTasks(now),
      events: seedEvents(now),
      active: null,
      lastResult: null,
      lockUntil: null,

      setBlockYouTube: (on) => {
        if (!on && isLocked(get().lockUntil)) return;
        set({ blockYouTube: on });
      },
      setBlockInstagram: (on) => {
        if (!on && isLocked(get().lockUntil)) return;
        set({ blockInstagram: on });
      },
      setScheduleOn: (on) => {
        if (!on && isLocked(get().lockUntil)) return;
        set({ scheduleOn: on });
      },
      // Locking turns Shorts and Reels blocking on. A running lock can only be extended, never shortened.
      startLock: (minutes) => {
        const until = Date.now() + minutes * 60000;
        const current = get().lockUntil;
        set({
          lockUntil: isLocked(current) && current !== null ? Math.max(current, until) : until,
          blockYouTube: true,
          blockInstagram: true,
        });
      },

      toggleTask: (id) => {
        const today = dayKey(Date.now());
        set({
          tasks: get().tasks.map((t) => (t.id === id ? { ...t, doneOn: t.doneOn === today ? null : today } : t)),
        });
      },
      saveTask: (task) => {
        const exists = get().tasks.some((t) => t.id === task.id);
        const tasks = exists ? get().tasks.map((t) => (t.id === task.id ? task : t)) : [...get().tasks, task];
        set({ tasks: [...tasks].sort((a, b) => a.start - b.start) });
      },
      deleteTask: (id) => set({ tasks: get().tasks.filter((t) => t.id !== id) }),

      setSiteBlocked: (id, blocked) => {
        if (!blocked && isLocked(get().lockUntil)) return;
        set({
          sites: get().sites.map((s) => (s.id === id ? { ...s, blocked } : s)),
        });
      },
      addSite: (site) => set({ sites: [...get().sites, site] }),
      deleteSite: (id) => {
        const site = get().sites.find((s) => s.id === id);
        if (site?.blocked && isLocked(get().lockUntil)) return;
        set({ sites: get().sites.filter((s) => s.id !== id) });
      },

      saveSchedule: (schedule) => {
        const exists = get().schedules.some((s) => s.id === schedule.id);
        set({
          schedules: exists
            ? get().schedules.map((s) => (s.id === schedule.id ? schedule : s))
            : [...get().schedules, schedule],
        });
      },
      deleteSchedule: (id) => set({ schedules: get().schedules.filter((s) => s.id !== id) }),

      setMessage: (message) => set({ message }),

      startSession: (name, minutes) =>
        set({
          active: { name, minutes, startedAt: Date.now() },
          lastResult: null,
        }),
      finishSession: (completed) => {
        const active = get().active;
        if (!active) return null;
        const at = Date.now();
        const elapsed = Math.round((at - active.startedAt) / 60000);
        const minutes = completed ? active.minutes : Math.min(active.minutes, elapsed);
        if (minutes < 1) {
          set({ active: null });
          return null;
        }
        const before = streakInfo(get().events, at).current;
        const sessionEvent: ActivityEvent = {
          id: newID('s'),
          kind: 'session',
          session: active.name,
          at,
          minutes,
          completed,
        };
        const withSession = [sessionEvent, ...get().events];
        const after = streakInfo(withSession, at).current;
        const newMilestone = after > before && after >= 2;
        const events: ActivityEvent[] = newMilestone
          ? [{ id: newID('m'), kind: 'milestone', days: after, at: at + 1 }, ...withSession]
          : withSession;
        const result: SessionResult = {
          name: active.name,
          minutes,
          completed,
          streak: after,
          newMilestone,
        };
        set({ events, active: null, lastResult: result });
        return result;
      },
      cancelSession: () => set({ active: null }),
    }),
    {
      name: 'focusflow',
      storage: createJSONStorage(() => zustandStorage),
    },
  ),
);

export { newID };
