import { useRouter } from 'expo-router';
import { useState } from 'react';

import { Field, PrimaryButton, SecondaryButton, SheetBody, SheetTitle } from '@/features/focus/components/sheet-parts';
import { useFocusStore } from '@/features/focus/store/focus-store';

const DEFAULT = { title: 'Stay on track!', body: 'This site is blocked so you can focus on what matters.' };

export default function MessageSheet() {
  const router = useRouter();
  const message = useFocusStore((s) => s.message);
  const setMessage = useFocusStore((s) => s.setMessage);
  const [title, setTitle] = useState(message.title);
  const [body, setBody] = useState(message.body);

  return (
    <SheetBody>
      <SheetTitle title="Redirect message" subtitle="What you see when you open a blocked Short or Reel." />
      <Field label="HEADLINE" value={title} onChangeText={setTitle} placeholder={DEFAULT.title} maxLength={40} />
      <Field label="MESSAGE" value={body} onChangeText={setBody} placeholder={DEFAULT.body} multiline maxLength={140} />
      <PrimaryButton
        label="Save message"
        disabled={!title.trim()}
        onPress={() => {
          setMessage({ title: title.trim(), body: body.trim() });
          router.back();
        }}
      />
      <SecondaryButton
        label="Use the default"
        onPress={() => {
          setTitle(DEFAULT.title);
          setBody(DEFAULT.body);
        }}
      />
    </SheetBody>
  );
}
