import { useLocalSearchParams, useRouter } from 'expo-router';
import { Switch } from 'heroui-native';
import { Text, View } from 'react-native';

import { PlatformLogo } from '@/features/focus/components/platform-logo';
import { PrimaryButton, SecondaryButton, SheetBody, SheetTitle } from '@/features/focus/components/sheet-parts';
import { useLock } from '@/features/focus/hooks/use-lock';
import { useFocusStore } from '@/features/focus/store/focus-store';
import { formatMinutes } from '@/features/focus/utils/dates';
import { confirmDelete } from '@/lib/confirm';

export default function SiteSheet() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const site = useFocusStore((s) => s.sites.find((x) => x.id === id));
  const events = useFocusStore((s) => s.events);
  const setSiteBlocked = useFocusStore((s) => s.setSiteBlocked);
  const deleteSite = useFocusStore((s) => s.deleteSite);
  const lock = useLock();

  if (!site) {
    return (
      <SheetBody>
        <SheetTitle title="Site removed" subtitle="This site is no longer on your list." />
        <PrimaryButton label="Close" onPress={() => router.back()} />
      </SheetBody>
    );
  }

  const blocks = events.filter((e) => e.kind === 'block' && e.platform === site.platform && site.platform !== 'other');
  const held = lock.locked && site.blocked;
  const saved = blocks.reduce((sum, e) => sum + (e.kind === 'block' ? e.minutes : 0), 0);

  return (
    <SheetBody>
      <SheetTitle
        title={site.name}
        subtitle={`${site.domain} · ${site.category}`}
        left={<PlatformLogo platform={site.platform} />}
      />
      <View className="flex-row items-center gap-3 rounded-xl border border-border bg-surface-secondary px-4 py-3">
        <View className="flex-1 gap-0.5">
          <Text className="text-sm font-medium text-foreground">Block during focus</Text>
          <Text className="text-xs text-muted">
            {held ? `Locked until ${lock.endLabel}` : site.blocked ? 'Blocked while you focus' : 'Allowed'}
          </Text>
        </View>
        <Switch
          isSelected={site.blocked}
          isDisabled={held}
          onSelectedChange={(v) => setSiteBlocked(site.id, v)}
          accessibilityLabel={`Block ${site.name}`}
        />
      </View>
      <View className="flex-row gap-3">
        <View className="flex-1 gap-0.5 rounded-xl border border-border bg-surface-secondary px-4 py-3">
          <Text className="text-[11px] text-muted">Times blocked</Text>
          <Text className="text-lg font-bold text-foreground">{blocks.length}</Text>
        </View>
        <View className="flex-1 gap-0.5 rounded-xl border border-border bg-surface-secondary px-4 py-3">
          <Text className="text-[11px] text-muted">Time saved</Text>
          <Text className="text-lg font-bold text-foreground">{formatMinutes(saved)}</Text>
        </View>
      </View>
      <View className="gap-2.5">
        <PrimaryButton label="Done" onPress={() => router.back()} />
        {held ? null : (
          <SecondaryButton
            danger
            label="Remove from list"
            onPress={() =>
              confirmDelete({
                title: `Remove ${site.name}?`,
                message: 'It will no longer be blocked during focus.',
                confirmLabel: 'Remove',
                onConfirm: () => {
                  deleteSite(site.id);
                  router.back();
                },
              })
            }
          />
        )}
      </View>
    </SheetBody>
  );
}
