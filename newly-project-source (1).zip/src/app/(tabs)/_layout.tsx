import { View } from 'react-native';

import AppTabs from '@/components/app-tabs';
import { StatusFade } from '@/components/status-fade';

export default function TabsLayout() {
  return (
    <View className="flex-1 bg-background">
      <AppTabs />
      <StatusFade />
    </View>
  );
}
