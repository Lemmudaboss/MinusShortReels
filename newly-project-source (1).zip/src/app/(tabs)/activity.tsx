import { useRouter } from 'expo-router';
import type { SymbolViewProps } from 'expo-symbols';
import { useState } from 'react';
import { ScrollView, Text, View } from 'react-native';

import { Card } from '@/components/card';
import { Image } from '@/components/image';
import { Pressable } from '@/components/pressable';
import { ActivityRow } from '@/features/focus/components/activity-row';
import { Glow } from '@/features/focus/components/glow';
import { Glyph } from '@/features/focus/components/glyph';
import { useOverview } from '@/features/focus/hooks/use-overview';
import { usePalette } from '@/features/focus/hooks/use-palette';
import { addDays, formatMinutes, startOfDay, startOfWeek } from '@/features/focus/utils/dates';
import { blockCountBetween, focusedBetween, savedBetween, scoreForDay } from '@/features/focus/utils/stats';

const mascotWave = require('@/assets/images/art/mascot-wave.png');
const mascotJoy = require('@/assets/images/art/mascot-joy.png');

export default function ActivityScreen() {
  const router = useRouter();
  const palette = usePalette();
  const o = useOverview();
  const [lastWeek, setLastWeek] = useState(false);
  const [showAll, setShowAll] = useState(false);

  const from = addDays(startOfWeek(o.now), lastWeek ? -7 : 0);
  const to = lastWeek ? startOfWeek(o.now) : o.now + 1;
  const blocked = blockCountBetween(o.events, from, to);
  const saved = savedBetween(o.events, from, to);
  const focused = focusedBetween(o.events, from, to);
  const dayCount = Math.max(1, Math.ceil((Math.min(to, o.now + 1) - from) / 86400000));
  const scores = Array.from({ length: dayCount }, (_, i) => {
    const day = addDays(from, i);
    return scoreForDay(o.events, day, startOfDay(day) === startOfDay(o.now) ? o.tasksDone : 2);
  });
  const avgScore = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
  const streak = o.streak.current;
  const dots = Math.min(7, Math.max(streak, 1));
  const list = showAll ? o.events : o.events.slice(0, 8);

  return (
    <ScrollView className="flex-1 bg-background" contentContainerClassName="px-5 pt-safe-offset-2 pb-safe-offset-22 gap-3">
      <View className="flex-row items-center">
        <View className="flex-1 gap-1">
          <Text className="text-3xl font-bold text-foreground">Activity</Text>
          <Text className="text-xs text-lilac">A distraction-free you is a happier you.</Text>
        </View>
        <View className="items-center justify-center">
          <View className="absolute">
            <Glow size={130} opacity={0.35} />
          </View>
          <Image source={mascotWave} className="w-24 h-24" contentFit="contain" />
        </View>
      </View>

      <Card>
        <View className="flex-row items-start gap-3">
          <View className="flex-1 gap-1">
            <Text className="text-base font-semibold text-foreground">
              {lastWeek ? 'Your Impact Last Week' : 'Your Impact This Week'}
            </Text>
            <Text className="text-xs leading-4 text-lilac">
              {`You prevented ${blocked} distractions and saved ${formatMinutes(saved)} from scrolling.`}
            </Text>
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Change week"
            onPress={() => setLastWeek(!lastWeek)}
            className="flex-row items-center gap-1.5 rounded-full border border-border bg-surface-secondary px-3 py-1.5">
            <Text className="text-xs text-foreground">{lastWeek ? 'Last Week' : 'This Week'}</Text>
            <Glyph name={{ ios: 'arrow.left.arrow.right', android: 'swap_horiz' }} size={10} color={palette.muted} />
          </Pressable>
        </View>
        <View className="flex-row gap-2">
          <Impact icon={{ ios: 'speaker.slash.fill', android: 'volume_off' }} value={`${blocked}`} label="Distractions blocked" />
          <Impact icon={{ ios: 'clock', android: 'schedule' }} value={formatMinutes(focused)} label="Time focused" />
          <Impact icon={{ ios: 'flame.fill', android: 'local_fire_department' }} value={`${streak}`} label="Day streak" />
          <Impact icon={{ ios: 'scope', android: 'track_changes' }} value={`${avgScore}%`} label="Focus score avg." />
        </View>
      </Card>

      <Card>
        <View className="flex-row items-center">
          <View className="flex-1 gap-1.5">
            <Text className="text-lg font-bold text-foreground">
              {streak > 0 ? `${streak} Day Streak!` : 'Start a streak'}
            </Text>
            <Text className="text-xs text-lilac">
              {streak > 0 ? "You're building amazing habits." : 'Finish a focus session today to begin.'}
            </Text>
            <View className="flex-row gap-1.5 pt-1">
              {Array.from({ length: dots }, (_, i) => (
                <View
                  key={i}
                  className={i < streak ? 'size-7 items-center justify-center rounded-full bg-accent' : 'size-7 rounded-full border border-border'}>
                  {i < streak ? <Glyph name={{ ios: 'checkmark', android: 'check' }} size={12} color={palette.foreground} weight="bold" /> : null}
                </View>
              ))}
            </View>
          </View>
          <View className="items-center justify-center">
            <View className="absolute">
              <Glow size={130} opacity={0.4} />
            </View>
            <Image source={mascotJoy} className="w-28 h-24" contentFit="contain" />
          </View>
        </View>
      </Card>

      <View className="flex-row items-center justify-between pt-2">
        <Text className="text-xl font-semibold text-foreground">Recent Activity</Text>
        <Pressable accessibilityRole="button" hitSlop={10} onPress={() => setShowAll(!showAll)}>
          <Text className="text-sm font-medium text-lilac">{showAll ? 'Show Less' : 'All Activity'}</Text>
        </Pressable>
      </View>
      {list.length === 0 ? (
        <Card>
          <Text className="text-sm text-muted">Nothing yet. Start a focus session and blocks will show up here.</Text>
        </Card>
      ) : (
        <Card list>
          {list.map((e) => (
            <ActivityRow
              key={e.id}
              event={e}
              now={o.now}
              onPress={() => router.push({ pathname: '/event', params: { id: e.id } })}
            />
          ))}
        </Card>
      )}
    </ScrollView>
  );
}

function Impact({ icon, value, label }: { icon: SymbolViewProps['name']; value: string; label: string }) {
  const palette = usePalette();
  return (
    <View className="flex-1 items-center gap-1 rounded-xl border border-border bg-surface-secondary px-1 py-3">
      <Glyph name={icon} size={18} color={palette.lilac} />
      <Text className="text-base font-bold text-foreground" numberOfLines={1} adjustsFontSizeToFit>
        {value}
      </Text>
      <Text className="text-center text-[10px] leading-3 text-muted">{label}</Text>
    </View>
  );
}
