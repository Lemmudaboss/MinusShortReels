import { useRouter } from 'expo-router';
import type { SymbolViewProps } from 'expo-symbols';
import type { ReactNode } from 'react';
import { ScrollView, Text, View } from 'react-native';

import { Card } from '@/components/card';
import { Image } from '@/components/image';
import { ChevronButton } from '@/components/list-row';
import { Segmented } from '@/components/segmented';
import { Glow } from '@/features/focus/components/glow';
import { Glyph } from '@/features/focus/components/glyph';
import { HourlyChart } from '@/features/focus/components/hourly-chart';
import { IconTile } from '@/features/focus/components/icon-tile';
import { PlatformLogo } from '@/features/focus/components/platform-logo';
import { ScoreHeader } from '@/features/focus/components/score-header';
import { WeekBars } from '@/features/focus/components/week-bars';
import { usePalette } from '@/features/focus/hooks/use-palette';
import { useStatsScreen, type StatsRange } from '@/features/focus/hooks/use-stats-screen';
import type { PlatformKey } from '@/features/focus/types/focus';
import { formatMinutes } from '@/features/focus/utils/dates';

const mascotStats = require('@/assets/images/art/mascot-stats.png');
const mascotCheer = require('@/assets/images/art/mascot-cheer.png');
const sceneCalm = require('@/assets/images/art/scene-calm.png');

export default function StatsScreen() {
  const router = useRouter();
  const palette = usePalette();
  const s = useStatsScreen();
  const daily = s.range === 'daily';
  const unit = daily ? (s.offset === 0 ? 'today' : 'that day') : 'this week';
  const more = s.savedDelta >= 0;

  return (
    <ScrollView className="flex-1 bg-background" contentContainerClassName="px-5 pt-safe-offset-2 pb-safe-offset-22 gap-3">
      <View className="flex-row items-center">
        <View className="flex-1">
          <ScoreHeader score={s.score} delta={s.scoreDelta} label={s.label} onInfo={() => router.push('/score')} />
        </View>
        <View className="items-center justify-center">
          <View className="absolute">
            <Glow size={130} opacity={0.35} />
          </View>
          <Image source={mascotStats} className="w-24 h-24" contentFit="contain" />
        </View>
      </View>

      <View className="flex-row items-center gap-3">
        <View className="flex-1">
          <Segmented<StatsRange>
            values={['daily', 'weekly']}
            labels={['Daily', 'Weekly']}
            value={s.range}
            onChange={s.setRange}
          />
        </View>
        <View className="flex-row items-center gap-2">
          {s.canOlder ? (
            <ChevronButton variant="circle" back accessibilityLabel="Earlier" onPress={s.older} />
          ) : (
            <View className="size-8" />
          )}
          <Text className="w-24 text-center text-xs font-medium text-foreground">{s.label}</Text>
          {s.offset > 0 ? (
            <ChevronButton variant="circle" accessibilityLabel="Later" onPress={s.newer} />
          ) : (
            <View className="size-8" />
          )}
        </View>
      </View>

      <Card>
        <View className="flex-row items-center gap-2.5">
          <IconTile name={{ ios: 'clock', android: 'schedule' }} size="sm" />
          <Text className="text-sm font-medium text-foreground">Time Saved from Scrolling</Text>
        </View>
        <View className="flex-row items-end gap-3">
          <View className="gap-1 pb-4">
            <Text className="text-3xl font-bold text-foreground">{formatMinutes(s.saved)}</Text>
            <Delta value={`${formatMinutes(Math.abs(s.savedDelta))} ${s.vsLabel}`} up={more} />
          </View>
          <HourlyChart values={s.chart} labels={s.chartLabels} height={84} />
        </View>
      </Card>

      <Card>
        <View className="flex-row items-center gap-3">
          <Image source={mascotCheer} className="w-20 h-16" contentFit="contain" />
          <View className="flex-1 gap-1">
            <Text className="text-sm font-semibold text-foreground">
              {more
                ? `You saved ${formatMinutes(s.savedDelta)} more ${daily ? 'than the day before' : 'than the week before'}!`
                : `${formatMinutes(s.saved)} saved ${unit}. Every minute counts.`}
            </Text>
            <Text className="text-xs text-lilac">{`That's like watching ${s.videos} fewer short videos.`}</Text>
          </View>
          <ChevronButton variant="circle" accessibilityLabel="See activity" onPress={() => router.push('/activity')} />
        </View>
      </Card>

      <View className="flex-row gap-2.5">
        <StatTile
          icon={{ ios: 'play.rectangle.fill', android: 'smart_display' }}
          label="Videos Blocked"
          value={`${s.videos}`}
          foot={<Delta value={`${Math.abs(s.videosDelta)}`} up={s.videosDelta >= 0} />}
        />
        <StatTile
          icon={{ ios: 'flame.fill', android: 'local_fire_department' }}
          label="Focus Streak"
          value={`${s.streak.current} ${s.streak.current === 1 ? 'day' : 'days'}`}
          foot={
            <View className="flex-row items-center gap-1">
              <Glyph name={{ ios: 'flame.fill', android: 'local_fire_department' }} size={10} color={palette.danger} />
              <Text className="text-[10px] text-muted">{`Longest: ${s.streak.longest} days`}</Text>
            </View>
          }
        />
        <StatTile
          icon={{ ios: 'chart.bar.fill', android: 'bar_chart' }}
          label="Daily Average"
          value={formatMinutes(s.average)}
          foot={<Delta value={formatMinutes(Math.abs(s.averageDelta))} up={s.averageDelta >= 0} />}
        />
      </View>

      <Card>
        <View className="flex-row items-center gap-3">
          <View className="gap-1.5">
            <View className="flex-row items-center gap-2.5">
              <IconTile name={{ ios: 'clock', android: 'schedule' }} size="sm" tone="soft" />
              <Text className="text-sm font-medium text-foreground">Time Saved This Week</Text>
            </View>
            <Text className="text-3xl font-bold text-foreground">{formatMinutes(s.thisWeek)}</Text>
            <Delta
              value={`${formatMinutes(Math.abs(s.weekDelta))}${s.lastWeekSpan > 0 ? ` (${Math.round((Math.abs(s.weekDelta) / s.lastWeekSpan) * 100)}%)` : ''}`}
              up={s.weekDelta >= 0}
            />
          </View>
          <View className="flex-1">
            <WeekBars values={s.weekValues} height={52} highlight={s.todayIndex} showValues barWidth={16} compact />
          </View>
        </View>
      </Card>

      <Card>
        <View className="flex-row items-center justify-between">
          <View className="flex-row items-center gap-2.5">
            <IconTile name={{ ios: 'minus.circle', android: 'do_not_disturb_on' }} size="sm" tone="soft" />
            <Text className="text-sm font-medium text-foreground">What You Avoided</Text>
          </View>
          <ChevronButton accessibilityLabel="See all activity" onPress={() => router.push('/activity')} />
        </View>
        <View className="flex-row">
          <Avoided platform="youtube" count={s.avoided.youtube} label="YouTube Shorts" />
          <View className="w-px bg-border" />
          <Avoided platform="instagram" count={s.avoided.instagram} label="Instagram Reels" />
          <View className="w-px bg-border" />
          <Avoided platform="tiktok" count={s.avoided.tiktok} label="TikTok" />
          <View className="w-px bg-border" />
          <Avoided platform="other" count={s.avoided.other} label="Other" />
        </View>
      </Card>

      <Card
        media={
          <View className="h-36 justify-center">
            <Image source={sceneCalm} className="absolute inset-0" contentFit="cover" contentPosition="right" />
            <View className="gap-1.5 p-5">
              <Text className="text-xl font-semibold leading-6 text-foreground">{'A calmer mind\na brighter you.'}</Text>
              <Text className="text-xs text-lilac">You&apos;re building a better tomorrow.</Text>
            </View>
          </View>
        }
      />
    </ScrollView>
  );
}

function Delta({ value, up }: { value: string; up: boolean }) {
  const palette = usePalette();
  return (
    <View className="flex-row items-center gap-1">
      <Glyph
        name={up ? { ios: 'arrow.up.right', android: 'north_east' } : { ios: 'arrow.down.right', android: 'south_east' }}
        size={11}
        color={palette.lilac}
      />
      <Text className="text-xs font-medium text-lilac">{`${up ? '+' : '−'}${value}`}</Text>
    </View>
  );
}

interface StatTileProps {
  icon: SymbolViewProps['name'];
  label: string;
  value: string;
  foot: ReactNode;
}

function StatTile({ icon, label, value, foot }: StatTileProps) {
  return (
    <View className="flex-1">
      <Card>
        <IconTile name={icon} size="sm" />
        <View className="gap-1">
          <Text className="text-[11px] text-muted">{label}</Text>
          <Text className="text-lg font-bold text-foreground" numberOfLines={1} adjustsFontSizeToFit>
            {value}
          </Text>
          {foot}
        </View>
      </Card>
    </View>
  );
}

function Avoided({ platform, count, label }: { platform: PlatformKey; count: number; label: string }) {
  return (
    <View className="flex-1 items-center gap-1">
      <PlatformLogo platform={platform} size="sm" />
      <Text className="text-base font-semibold text-foreground">{count}</Text>
      <Text className="text-[10px] text-muted" numberOfLines={1}>
        {label}
      </Text>
    </View>
  );
}
