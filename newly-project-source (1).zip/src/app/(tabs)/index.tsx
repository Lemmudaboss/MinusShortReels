import { useRouter } from 'expo-router';
import { Switch } from 'heroui-native';
import { ScrollView, Text, View } from 'react-native';

import { Card } from '@/components/card';
import { Image } from '@/components/image';
import { ChevronButton } from '@/components/list-row';
import { Pressable } from '@/components/pressable';
import { ActivityRow } from '@/features/focus/components/activity-row';
import { Divider } from '@/features/focus/components/divider';
import { Glow } from '@/features/focus/components/glow';
import { Glyph } from '@/features/focus/components/glyph';
import { IconTile } from '@/features/focus/components/icon-tile';
import { PlatformLogo } from '@/features/focus/components/platform-logo';
import { ScoreHeader } from '@/features/focus/components/score-header';
import { TaskRow, TasksCount } from '@/features/focus/components/task-row';
import { WeekBars } from '@/features/focus/components/week-bars';
import { useLock } from '@/features/focus/hooks/use-lock';
import { useOverview } from '@/features/focus/hooks/use-overview';
import { usePalette } from '@/features/focus/hooks/use-palette';
import { useFocusStore } from '@/features/focus/store/focus-store';
import type { PlatformKey } from '@/features/focus/types/focus';
import { dayKey, formatMinutes } from '@/features/focus/utils/dates';

const mascot = require('@/assets/images/art/mascot-meditate.png');

export default function HomeScreen() {
  const router = useRouter();
  const palette = usePalette();
  const o = useOverview();
  const blockYouTube = useFocusStore((s) => s.blockYouTube);
  const blockInstagram = useFocusStore((s) => s.blockInstagram);
  const setBlockYouTube = useFocusStore((s) => s.setBlockYouTube);
  const setBlockInstagram = useFocusStore((s) => s.setBlockInstagram);
  const toggleTask = useFocusStore((s) => s.toggleTask);
  const active = useFocusStore((s) => s.active);
  const lock = useLock();
  const todayKey = dayKey(o.now);
  const remaining = active ? Math.max(0, Math.ceil((active.startedAt + active.minutes * 60000 - o.now) / 60000)) : 0;

  return (
    <ScrollView
      className="flex-1 bg-background"
      contentContainerClassName="px-5 pt-safe-offset-2 pb-safe-offset-22 gap-3">
      <ScoreHeader score={o.score} delta={o.scoreDelta} label={o.label} onInfo={() => router.push('/score')} />

      <Card>
        <View className="flex-row items-center gap-3">
          <View className="items-center justify-center">
            <View className="absolute">
              <Glow size={150} opacity={0.35} />
            </View>
            <Image source={mascot} className="w-28 h-24" contentFit="contain" />
          </View>
          <View className="flex-1 gap-1.5">
            <View className="flex-row items-start justify-between">
              <Text className="text-[10px] font-semibold tracking-widest text-muted">TODAY&apos;S FOCUS</Text>
              <ChevronButton
                variant="circle"
                accessibilityLabel="See your stats"
                onPress={() => router.push('/stats')}
              />
            </View>
            <Text className="text-lg font-semibold text-foreground">{active ? active.name : 'Deep Work Session'}</Text>
            <Text className="text-xs leading-4 text-muted">
              {active
                ? `${remaining} min left. Your phone can wait — the momentum can't.`
                : `Keep the momentum going. You've blocked ${(o.todaySaved / 60).toFixed(1)}h of distracting content today.`}
            </Text>
            <Pressable
              accessibilityRole="button"
              onPress={() => router.push('/focus')}
              className="self-start flex-row items-center gap-2 rounded-xl bg-accent px-4 py-2.5">
              <Glyph name={{ ios: 'play.fill', android: 'play_arrow' }} size={12} color={palette.foreground} />
              <Text className="text-sm font-semibold text-accent-foreground">
                {active ? 'Resume focus' : 'Start 25 min focus'}
              </Text>
            </Pressable>
          </View>
        </View>
      </Card>

      <View className="flex-row items-center justify-between pt-2">
        <Text className="text-xl font-semibold text-foreground">Content Blocking</Text>
        <Pressable accessibilityRole="button" hitSlop={10} onPress={() => router.push('/rules')}>
          <Text className="text-sm font-medium text-lilac">Edit</Text>
        </Pressable>
      </View>
      <View className="flex-row gap-3">
        <BlockToggle
          platform="youtube"
          name="YouTube"
          content="Shorts"
          on={blockYouTube}
          locked={lock.locked}
          saved={o.youtubeToday}
          onChange={setBlockYouTube}
        />
        <BlockToggle
          platform="instagram"
          name="Instagram"
          content="Reels"
          on={blockInstagram}
          locked={lock.locked}
          saved={o.instagramToday}
          onChange={setBlockInstagram}
        />
      </View>
      <Card>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={lock.locked ? `Blocking locked until ${lock.endLabel}` : 'Lock blocking'}
          onPress={() => router.push('/lock')}
          className="flex-row items-center gap-3">
          <IconTile
            name={lock.locked ? { ios: 'lock.fill', android: 'lock' } : { ios: 'lock.open', android: 'lock_open' }}
            tone={lock.locked ? 'solid' : 'soft'}
          />
          <View className="flex-1 gap-0.5">
            <Text className="text-sm font-semibold text-foreground" numberOfLines={1}>
              {lock.locked ? `Locked until ${lock.endLabel}` : 'Lock blocking'}
            </Text>
            <Text className="text-[11px] text-muted" numberOfLines={1}>
              {lock.locked
                ? `${lock.left} · no turning it off early`
                : "Commit for a set time. You won't be able to undo it."}
            </Text>
          </View>
          <Text className="text-sm font-medium text-lilac">{lock.locked ? 'Add time' : 'Lock'}</Text>
        </Pressable>
      </Card>

      <Card>
        <View className="flex-row items-center gap-3">
          <IconTile name={{ ios: 'clock', android: 'schedule' }} />
          <View className="gap-0.5">
            <Text className="text-xs text-muted">Total Saved This Week</Text>
            <Text className="text-2xl font-bold text-foreground">{formatMinutes(o.thisWeek)}</Text>
            <Delta value={o.weekDelta} />
          </View>
          <View className="flex-1">
            <WeekBars values={o.week} height={44} highlight={o.todayIndex} barWidth={13} compact />
          </View>
        </View>
      </Card>

      <Card>
        <View className="flex-row items-center justify-between">
          <Text className="text-base font-semibold text-foreground">Today&apos;s Tasks</Text>
          <TasksCount done={o.tasksDone} total={o.tasks.length} />
        </View>
        <View>
          {o.tasks.map((t, i) => (
            <View key={t.id}>
              {i > 0 ? <Divider inset /> : null}
              <TaskRow
                task={t}
                done={t.doneOn === todayKey}
                onToggle={() => toggleTask(t.id)}
                onOpen={() => router.push({ pathname: '/task', params: { id: t.id } })}
              />
            </View>
          ))}
          <Divider inset />
          <Pressable
            accessibilityRole="button"
            onPress={() => router.push('/task')}
            className="flex-row items-center gap-3 py-2.5">
            <View className="size-8 items-center justify-center rounded-full bg-iris-deep">
              <Glyph name={{ ios: 'plus', android: 'add' }} size={14} color={palette.lilac} />
            </View>
            <Text className="text-sm font-medium text-lilac">Add task</Text>
          </Pressable>
        </View>
      </Card>

      <Card>
        <View className="flex-row items-center justify-between">
          <Text className="text-base font-semibold text-foreground">Recent Activity</Text>
          <ChevronButton accessibilityLabel="See all activity" onPress={() => router.push('/activity')} />
        </View>
        <View>
          {o.events.slice(0, 3).map((e, i) => (
            <View key={e.id}>
              {i > 0 ? <Divider /> : null}
              <ActivityRow
                event={e}
                now={o.now}
                compact
                onPress={() => router.push({ pathname: '/event', params: { id: e.id } })}
              />
            </View>
          ))}
        </View>
      </Card>
    </ScrollView>
  );
}

function Delta({ value }: { value: number }) {
  const palette = usePalette();
  const up = value >= 0;
  return (
    <View className="flex-row items-center gap-1">
      <Glyph
        name={
          up ? { ios: 'arrow.up.right', android: 'north_east' } : { ios: 'arrow.down.right', android: 'south_east' }
        }
        size={11}
        color={palette.lilac}
      />
      <Text className="text-xs font-medium text-lilac">{`${up ? '+' : '−'}${formatMinutes(Math.abs(value))}`}</Text>
    </View>
  );
}

interface BlockToggleProps {
  platform: PlatformKey;
  name: string;
  content: string;
  on: boolean;
  locked: boolean;
  saved: number;
  onChange: (on: boolean) => void;
}

function BlockToggle({ platform, name, content, on, locked, saved, onChange }: BlockToggleProps) {
  const palette = usePalette();
  const held = locked && on;
  return (
    <View className="flex-1">
      <Card>
        <View className="flex-row items-center justify-between">
          <PlatformLogo platform={platform} size="sm" />
          <View className="flex-row items-center">
            {held ? <Glyph name={{ ios: 'lock.fill', android: 'lock' }} size={11} color={palette.lilac} /> : null}
            <Switch
              isSelected={on}
              isDisabled={held}
              onSelectedChange={(v) => {
                onChange(v);
              }}
              accessibilityLabel={`Block ${name} ${content}`}
              className="scale-75"
            />
          </View>
        </View>
        <View className="gap-0.5">
          <Text className="text-sm font-semibold text-foreground" numberOfLines={1}>
            {name} {content}
          </Text>
          <Text className="text-[11px] text-muted" numberOfLines={1}>
            {held ? 'Blocked · locked' : on ? 'Blocked' : 'Allowed'}
          </Text>
        </View>
        <View className="flex-row items-center gap-1.5">
          <Glyph name={{ ios: 'clock', android: 'schedule' }} size={11} color={palette.muted} />
          <Text className="text-[11px] text-muted">{on ? `${formatMinutes(saved)} saved today` : 'Not blocking'}</Text>
        </View>
      </Card>
    </View>
  );
}
