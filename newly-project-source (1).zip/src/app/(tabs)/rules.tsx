import { useRouter } from 'expo-router';
import { Switch } from 'heroui-native';
import { ScrollView, Text, View } from 'react-native';

import { Card } from '@/components/card';
import { Image } from '@/components/image';
import { ChevronButton } from '@/components/list-row';
import { Pressable } from '@/components/pressable';
import { Divider } from '@/features/focus/components/divider';
import { Glow } from '@/features/focus/components/glow';
import { Glyph } from '@/features/focus/components/glyph';
import { IconTile } from '@/features/focus/components/icon-tile';
import { PlatformLogo } from '@/features/focus/components/platform-logo';
import { ScheduleIcon } from '@/features/focus/components/schedule-icon';
import { usePalette } from '@/features/focus/hooks/use-palette';
import { useLock } from '@/features/focus/hooks/use-lock';
import { useFocusStore } from '@/features/focus/store/focus-store';
import { formatClock, formatDays } from '@/features/focus/utils/dates';
import { cn } from '@/lib/cn';

const mascotShield = require('@/assets/images/art/mascot-shield.png');
const mascotSmall = require('@/assets/images/art/mascot-small.png');
const sceneFlag = require('@/assets/images/art/scene-flag.png');

export default function RulesScreen() {
  const router = useRouter();
  const palette = usePalette();
  const sites = useFocusStore((s) => s.sites);
  const schedules = useFocusStore((s) => s.schedules);
  const scheduleOn = useFocusStore((s) => s.scheduleOn);
  const { locked } = useLock();
  const setScheduleOn = useFocusStore((s) => s.setScheduleOn);
  const message = useFocusStore((s) => s.message);
  const blockYouTube = useFocusStore((s) => s.blockYouTube);
  const blockInstagram = useFocusStore((s) => s.blockInstagram);
  const blockedCount = sites.filter((s) => s.blocked).length;
  const shortForm = [blockYouTube ? 'Shorts' : null, blockInstagram ? 'Reels' : null].filter(Boolean).join(' & ');

  return (
    <ScrollView
      className="flex-1 bg-background"
      contentContainerClassName="px-5 pt-safe-offset-2 pb-safe-offset-22 gap-3">
      <View className="flex-row items-center">
        <View className="flex-1 gap-1">
          <Text className="text-3xl font-bold text-foreground">Rules</Text>
          <Text className="text-xs leading-4 text-lilac">
            Customize what gets blocked, when, and how you stay focused.
          </Text>
        </View>
        <View className="items-center justify-center">
          <View className="absolute">
            <Glow size={140} opacity={0.35} />
          </View>
          <Image source={mascotShield} className="w-32 h-24" contentFit="contain" />
        </View>
      </View>

      <Card>
        <Pressable
          accessibilityRole="button"
          onPress={() => router.push('/add-site')}
          className="flex-row items-center gap-3">
          <IconTile name={{ ios: 'nosign', android: 'block' }} />
          <View className="flex-1 gap-0.5">
            <Text className="text-base font-semibold text-foreground">Blocked Sites & Apps</Text>
            <Text className="text-xs text-muted">These sites and apps are blocked during focus.</Text>
          </View>
        </Pressable>
        <View>
          {sites.map((site, i) => (
            <View key={site.id}>
              {i > 0 ? <Divider inset /> : null}
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={`${site.name}, ${site.blocked ? 'blocked' : 'allowed'}`}
                onPress={() => router.push({ pathname: '/site', params: { id: site.id } })}
                className="flex-row items-center gap-3 py-2.5">
                <PlatformLogo platform={site.platform} />
                <View className="flex-1 gap-0.5">
                  <Text className="text-sm font-medium text-foreground">{site.name}</Text>
                  <Text className="text-xs text-muted">{site.category}</Text>
                </View>
                <View className={cn('rounded-lg px-2.5 py-1', site.blocked ? 'bg-ember-soft' : 'bg-default')}>
                  <Text className={cn('text-xs font-medium', site.blocked ? 'text-ember' : 'text-muted')}>
                    {site.blocked ? 'Blocked' : 'Allowed'}
                  </Text>
                </View>
                <ChevronButton
                  accessibilityLabel={`Open ${site.name}`}
                  onPress={() => router.push({ pathname: '/site', params: { id: site.id } })}
                />
              </Pressable>
            </View>
          ))}
        </View>
        <Pressable
          accessibilityRole="button"
          onPress={() => router.push('/add-site')}
          className="flex-row items-center justify-center gap-2 rounded-xl bg-iris-deep py-3">
          <Glyph name={{ ios: 'plus', android: 'add' }} size={14} color={palette.lilac} />
          <Text className="text-sm font-medium text-lilac">Add a Site or App</Text>
        </Pressable>
      </Card>

      <Card>
        <View className="flex-row items-center gap-3">
          <IconTile name={{ ios: 'clock', android: 'schedule' }} />
          <View className="flex-1 gap-0.5">
            <Text className="text-base font-semibold text-foreground">Strict Mode Schedule</Text>
            <Text className="text-xs text-muted">Automatically block during these times.</Text>
          </View>
          <Switch
            isSelected={scheduleOn}
            isDisabled={locked && scheduleOn}
            onSelectedChange={setScheduleOn}
            accessibilityLabel="Strict Mode Schedule"
          />
        </View>
        <View>
          {schedules.map((sc, i) => (
            <View key={sc.id}>
              {i > 0 ? <Divider inset /> : null}
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={`Edit ${sc.name}`}
                onPress={() => router.push({ pathname: '/schedule', params: { id: sc.id } })}
                className={cn('flex-row items-center gap-3 py-2.5', scheduleOn ? '' : 'opacity-50')}>
                <ScheduleIcon icon={sc.icon} />
                <View className="flex-1 gap-0.5">
                  <Text className="text-sm font-medium text-foreground">{sc.name}</Text>
                  <Text className="text-xs text-muted">{`${formatDays(sc.days)}   ${formatClock(sc.start)} – ${formatClock(sc.end)}`}</Text>
                </View>
                <Glyph name={{ ios: 'ellipsis', android: 'more_horiz' }} size={16} color={palette.muted} />
              </Pressable>
            </View>
          ))}
          <Divider inset />
          <Pressable
            accessibilityRole="button"
            onPress={() => router.push('/schedule')}
            className="flex-row items-center gap-3 py-2.5">
            <View className="size-9 items-center justify-center rounded-xl bg-surface-secondary">
              <Glyph name={{ ios: 'plus', android: 'add' }} size={16} color={palette.lilac} />
            </View>
            <Text className="flex-1 text-sm font-medium text-foreground">Add Schedule</Text>
          </Pressable>
        </View>
      </Card>

      <Card>
        <Pressable
          accessibilityRole="button"
          onPress={() => router.push('/message')}
          className="flex-row items-center gap-3">
          <IconTile name={{ ios: 'text.bubble.fill', android: 'chat' }} />
          <View className="flex-1 gap-0.5">
            <Text className="text-base font-semibold text-foreground">Custom Redirect Message</Text>
            <Text className="text-xs text-muted">Shown when you try to visit a blocked site.</Text>
          </View>
        </Pressable>
        <View className="flex-row items-center gap-3 overflow-hidden rounded-xl border border-border bg-surface-secondary">
          <Image source={sceneFlag} className="absolute right-0 bottom-0 w-24 h-14 opacity-80" contentFit="contain" />
          <Image source={mascotSmall} className="w-20 h-20" contentFit="contain" />
          <View className="flex-1 gap-1 py-3 pr-24">
            <Text className="text-base font-semibold text-foreground">{message.title}</Text>
            <Text className="text-xs text-muted">{message.body}</Text>
          </View>
        </View>
        <Pressable
          accessibilityRole="button"
          onPress={() => router.push('/message')}
          className="flex-row items-center justify-center gap-2 rounded-xl bg-iris-deep py-3">
          <Glyph name={{ ios: 'pencil', android: 'edit' }} size={14} color={palette.lilac} />
          <Text className="text-sm font-medium text-lilac">Edit Message</Text>
        </Pressable>
      </Card>

      <Card>
        <Pressable
          accessibilityRole="button"
          onPress={() => router.push('/activity')}
          className="flex-row items-center gap-3">
          <IconTile name={{ ios: 'chart.bar.fill', android: 'bar_chart' }} />
          <View className="flex-1 gap-0.5">
            <Text className="text-base font-semibold text-foreground">
              {blockedCount > 0 || shortForm ? 'Rules are working' : 'Nothing is blocked'}
            </Text>
            <Text className="text-xs text-muted">
              {`You've blocked ${blockedCount} ${blockedCount === 1 ? 'site' : 'sites'} • ${scheduleOn ? schedules.length : 0} ${schedules.length === 1 ? 'schedule' : 'schedules'} active`}
            </Text>
          </View>
        </Pressable>
      </Card>
    </ScrollView>
  );
}
