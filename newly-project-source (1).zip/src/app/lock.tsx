import { useRouter } from 'expo-router';
import { useState } from 'react';
import { Alert, Text, View } from 'react-native';
import { Presets } from 'react-native-pulsar';

import { IconTile } from '@/features/focus/components/icon-tile';
import {
  Chip,
  FieldLabel,
  PrimaryButton,
  SecondaryButton,
  SheetBody,
  SheetTitle,
} from '@/features/focus/components/sheet-parts';
import { useLock } from '@/features/focus/hooks/use-lock';
import { useFocusStore } from '@/features/focus/store/focus-store';
import { LOCK_OPTIONS, lockEndLabel } from '@/features/focus/utils/lock';

export default function LockSheet() {
  const router = useRouter();
  const lock = useLock();
  const startLock = useFocusStore((s) => s.startLock);
  const [minutes, setMinutes] = useState<number>(60);

  const base = lock.until ?? lock.now;
  const newEnd = lockEndLabel(base + minutes * 60000, lock.now);
  const choice = LOCK_OPTIONS.find((o) => o.minutes === minutes)?.label ?? '';

  const confirm = () => {
    Presets.System.notificationWarning();
    Alert.alert(
      lock.locked ? `Lock until ${newEnd}?` : `Lock for ${choice}?`,
      `Shorts, Reels and your blocked sites stay blocked until ${newEnd}. You can't turn them off or end the lock early.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Lock',
          onPress: () => {
            startLock(lock.locked ? Math.round((base - Date.now()) / 60000) + minutes : minutes);
            Presets.System.notificationSuccess();
            router.back();
          },
        },
      ],
    );
  };

  return (
    <SheetBody>
      <SheetTitle
        title={lock.locked ? 'Blocking is locked' : 'Lock blocking'}
        subtitle={
          lock.locked
            ? `Ends ${lock.endLabel} · ${lock.left}. You can add time, not remove it.`
            : "For the time you pick, Shorts, Reels and blocked sites can't be turned off — not even here."
        }
        left={<IconTile name={{ ios: 'lock.fill', android: 'lock' }} />}
      />
      <View className="gap-2">
        <FieldLabel>{lock.locked ? 'ADD TIME' : 'LOCK FOR'}</FieldLabel>
        <View className="flex-row flex-wrap gap-2">
          {LOCK_OPTIONS.map((o) => (
            <Chip
              key={o.minutes}
              label={lock.locked ? `+${o.label}` : o.label}
              on={o.minutes === minutes}
              onPress={() => setMinutes(o.minutes)}
            />
          ))}
        </View>
        <Text className="text-xs text-muted">{`Locked until ${newEnd}`}</Text>
      </View>
      <View className="gap-2.5">
        <PrimaryButton label={lock.locked ? `Extend to ${newEnd}` : `Lock for ${choice}`} onPress={confirm} />
        <SecondaryButton label={lock.locked ? 'Done' : 'Not now'} onPress={() => router.back()} />
      </View>
    </SheetBody>
  );
}
