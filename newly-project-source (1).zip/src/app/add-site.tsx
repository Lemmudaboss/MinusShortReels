import { useRouter } from 'expo-router';
import { useState } from 'react';
import { View } from 'react-native';

import { Chip, Field, FieldLabel, PrimaryButton, SheetBody, SheetTitle } from '@/features/focus/components/sheet-parts';
import { newID, useFocusStore } from '@/features/focus/store/focus-store';
import type { PlatformKey } from '@/features/focus/types/focus';

const CATEGORIES = ['Social Media', 'Video & Streaming', 'News', 'Shopping', 'Games'];

const KNOWN: Record<string, PlatformKey> = {
  'youtube.com': 'youtube',
  'instagram.com': 'instagram',
  'tiktok.com': 'tiktok',
  'x.com': 'x',
  'twitter.com': 'x',
  'reddit.com': 'reddit',
};

function cleanDomain(raw: string): string {
  return raw
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, '')
    .replace(/^www\./, '')
    .split('/')[0];
}

export default function AddSiteSheet() {
  const router = useRouter();
  const addSite = useFocusStore((s) => s.addSite);
  const sites = useFocusStore((s) => s.sites);
  const [domain, setDomain] = useState('');
  const [name, setName] = useState('');
  const [category, setCategory] = useState(CATEGORIES[0]);

  const clean = cleanDomain(domain);
  const valid = /^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(clean);
  const duplicate = sites.some((s) => s.domain === clean);
  const guessName = clean ? clean.split('.')[0].replace(/^./, (c) => c.toUpperCase()) : '';

  const save = () => {
    addSite({
      id: newID('site'),
      name: name.trim() || guessName,
      domain: clean,
      category,
      platform: KNOWN[clean] ?? 'other',
      blocked: true,
    });
    router.back();
  };

  return (
    <SheetBody>
      <SheetTitle title="Add a site or app" subtitle="It will be blocked whenever you focus." />
      <Field
        label="WEBSITE"
        value={domain}
        onChangeText={setDomain}
        placeholder="e.g. twitch.tv"
        autoCapitalize="none"
        autoCorrect={false}
        keyboardType="url"
        autoFocus
      />
      <Field label="NAME" value={name} onChangeText={setName} placeholder={guessName || 'e.g. Twitch'} />
      <View className="gap-2">
        <FieldLabel>CATEGORY</FieldLabel>
        <View className="flex-row flex-wrap gap-2">
          {CATEGORIES.map((c) => (
            <Chip key={c} label={c} on={c === category} onPress={() => setCategory(c)} />
          ))}
        </View>
      </View>
      <PrimaryButton
        label={duplicate ? 'Already on your list' : 'Add to blocked list'}
        onPress={save}
        disabled={!valid || duplicate}
      />
    </SheetBody>
  );
}
