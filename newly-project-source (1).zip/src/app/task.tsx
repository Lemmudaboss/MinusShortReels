import { useLocalSearchParams, useRouter } from 'expo-router';
import { useState } from 'react';
import { View } from 'react-native';

import { Field, PrimaryButton, SecondaryButton, SheetBody, SheetTitle, TimeField } from '@/features/focus/components/sheet-parts';
import { newID, useFocusStore } from '@/features/focus/store/focus-store';
import { confirmDelete } from '@/lib/confirm';

export default function TaskSheet() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id?: string }>();
  const existing = useFocusStore((s) => s.tasks.find((t) => t.id === id));
  const saveTask = useFocusStore((s) => s.saveTask);
  const deleteTask = useFocusStore((s) => s.deleteTask);
  const nextHour = (new Date().getHours() + 1) % 24;

  const [title, setTitle] = useState(existing?.title ?? '');
  const [start, setStart] = useState(existing?.start ?? nextHour * 60);
  const [end, setEnd] = useState(existing?.end ?? Math.min(24 * 60 - 1, nextHour * 60 + 60));

  const save = () => {
    saveTask({
      id: existing?.id ?? newID('t'),
      title: title.trim(),
      start,
      end: Math.max(end, start),
      doneOn: existing?.doneOn ?? null,
    });
    router.back();
  };

  return (
    <SheetBody>
      <SheetTitle title={existing ? 'Edit task' : 'New task'} subtitle="Plan it, then protect the time." />
      <Field label="TASK" value={title} onChangeText={setTitle} placeholder="e.g. Write project documentation" autoFocus={!existing} returnKeyType="done" />
      <View className="flex-row gap-3">
        <TimeField label="STARTS" value={start} onChange={setStart} />
        <TimeField label="ENDS" value={end} onChange={setEnd} />
      </View>
      <View className="gap-2.5">
        <PrimaryButton label={existing ? 'Save task' : 'Add task'} onPress={save} disabled={!title.trim()} />
        {existing ? (
          <SecondaryButton
            danger
            label="Delete task"
            onPress={() =>
              confirmDelete({
                title: 'Delete this task?',
                message: `"${existing.title}" will be removed from today's tasks.`,
                onConfirm: () => {
                  deleteTask(existing.id);
                  router.back();
                },
              })
            }
          />
        ) : null}
      </View>
    </SheetBody>
  );
}
