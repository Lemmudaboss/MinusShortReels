import { useLocalSearchParams, useRouter } from 'expo-router';
import { useState } from 'react';
import { View } from 'react-native';

import { Pressable } from '@/components/pressable';
import { Glyph } from '@/features/focus/components/glyph';
import { SCHEDULE_ICONS } from '@/features/focus/components/schedule-icon';
import {
  Chip,
  Field,
  FieldLabel,
  PrimaryButton,
  SecondaryButton,
  SheetBody,
  SheetTitle,
  TimeField,
} from '@/features/focus/components/sheet-parts';
import { usePalette } from '@/features/focus/hooks/use-palette';
import { newID, useFocusStore } from '@/features/focus/store/focus-store';
import type { ScheduleIcon } from '@/features/focus/types/focus';
import { cn } from '@/lib/cn';
import { confirmDelete } from '@/lib/confirm';

const DAYS = [
  { d: 1, l: 'Mon' },
  { d: 2, l: 'Tue' },
  { d: 3, l: 'Wed' },
  { d: 4, l: 'Thu' },
  { d: 5, l: 'Fri' },
  { d: 6, l: 'Sat' },
  { d: 0, l: 'Sun' },
];
const ICONS: ScheduleIcon[] = ['cup', 'moon', 'book', 'sun'];

export default function ScheduleSheet() {
  const router = useRouter();
  const palette = usePalette();
  const { id } = useLocalSearchParams<{ id?: string }>();
  const existing = useFocusStore((s) => s.schedules.find((x) => x.id === id));
  const saveSchedule = useFocusStore((s) => s.saveSchedule);
  const deleteSchedule = useFocusStore((s) => s.deleteSchedule);

  const [name, setName] = useState(existing?.name ?? '');
  const [icon, setIcon] = useState<ScheduleIcon>(existing?.icon ?? 'book');
  const [days, setDays] = useState<number[]>(existing?.days ?? [1, 2, 3, 4, 5]);
  const [start, setStart] = useState(existing?.start ?? 9 * 60);
  const [end, setEnd] = useState(existing?.end ?? 12 * 60);

  const toggleDay = (d: number) => setDays(days.includes(d) ? days.filter((x) => x !== d) : [...days, d].sort());

  const save = () => {
    saveSchedule({ id: existing?.id ?? newID('sc'), name: name.trim(), icon, days, start, end });
    router.back();
  };

  return (
    <SheetBody>
      <SheetTitle title={existing ? 'Edit schedule' : 'New schedule'} subtitle="Strict Mode blocks automatically at these times." />
      <Field label="NAME" value={name} onChangeText={setName} placeholder="e.g. Study Time" />
      <View className="gap-2">
        <FieldLabel>ICON</FieldLabel>
        <View className="flex-row gap-2">
          {ICONS.map((i) => (
            <Pressable
              key={i}
              accessibilityRole="button"
              accessibilityLabel={`${i} icon`}
              accessibilityState={{ selected: i === icon }}
              onPress={() => setIcon(i)}
              className={cn(
                'size-11 items-center justify-center rounded-xl border',
                i === icon ? 'border-accent bg-iris-deep' : 'border-border bg-surface-secondary',
              )}>
              <Glyph name={SCHEDULE_ICONS[i]} size={18} color={i === icon ? palette.foreground : palette.lilac} />
            </Pressable>
          ))}
        </View>
      </View>
      <View className="gap-2">
        <FieldLabel>DAYS</FieldLabel>
        <View className="flex-row flex-wrap gap-1.5">
          {DAYS.map(({ d, l }) => (
            <Chip key={d} label={l} on={days.includes(d)} onPress={() => toggleDay(d)} />
          ))}
        </View>
      </View>
      <View className="flex-row gap-3">
        <TimeField label="FROM" value={start} onChange={setStart} />
        <TimeField label="UNTIL" value={end} onChange={setEnd} />
      </View>
      <View className="gap-2.5">
        <PrimaryButton label="Save schedule" onPress={save} disabled={!name.trim() || days.length === 0} />
        {existing ? (
          <SecondaryButton
            danger
            label="Delete schedule"
            onPress={() =>
              confirmDelete({
                title: `Delete ${existing.name}?`,
                message: 'Strict Mode will stop blocking at these times.',
                onConfirm: () => {
                  deleteSchedule(existing.id);
                  router.back();
                },
              })
            }
          />
        ) : null}
      </View>
    </SheetBody>
  );
}
