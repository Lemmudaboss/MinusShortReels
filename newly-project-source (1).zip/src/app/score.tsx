import { useRouter } from 'expo-router';
import type { SymbolViewProps } from 'expo-symbols';
import { Text, View } from 'react-native';

import { Glyph } from '@/features/focus/components/glyph';
import { ScoreRing } from '@/features/focus/components/score-ring';
import { PrimaryButton, SheetBody, SheetTitle } from '@/features/focus/components/sheet-parts';
import { useOverview } from '@/features/focus/hooks/use-overview';
import { usePalette } from '@/features/focus/hooks/use-palette';

function Factor({ icon, title, body }: { icon: SymbolViewProps['name']; title: string; body: string }) {
  const palette = usePalette();
  return (
    <View className="flex-row items-start gap-3">
      <View className="size-8 items-center justify-center rounded-lg bg-iris-deep">
        <Glyph name={icon} size={15} color={palette.lilac} />
      </View>
      <View className="flex-1 gap-0.5">
        <Text className="text-sm font-medium text-foreground">{title}</Text>
        <Text className="text-xs text-muted">{body}</Text>
      </View>
    </View>
  );
}

export default function ScoreSheet() {
  const router = useRouter();
  const o = useOverview();
  return (
    <SheetBody>
      <SheetTitle
        title="Your Focus Score"
        subtitle={o.label}
        left={
          <ScoreRing size={56} stroke={5} progress={o.score / 100}>
            <Text className="text-base font-bold text-foreground">{o.score}</Text>
          </ScoreRing>
        }
      />
      <Text className="text-sm text-muted">A score out of 100 for today. It rises with three things:</Text>
      <View className="gap-4">
        <Factor icon={{ ios: 'timer', android: 'timer' }} title="Focus sessions" body="Minutes spent in a focus session today." />
        <Factor icon={{ ios: 'nosign', android: 'block' }} title="Distractions blocked" body="Time FocusFlow kept you out of Shorts and Reels." />
        <Factor icon={{ ios: 'checkmark.circle', android: 'check_circle' }} title="Tasks finished" body="Each task you tick off adds to the score." />
      </View>
      <PrimaryButton label="Got it" onPress={() => router.back()} />
    </SheetBody>
  );
}
