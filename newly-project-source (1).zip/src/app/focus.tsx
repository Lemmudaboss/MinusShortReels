import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { Text, View } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withDelay, withTiming } from 'react-native-reanimated';
import { Presets } from 'react-native-pulsar';

import { Image } from '@/components/image';
import { Pressable } from '@/components/pressable';
import { Glow } from '@/features/focus/components/glow';
import { Glyph } from '@/features/focus/components/glyph';
import { ScoreRing } from '@/features/focus/components/score-ring';
import { useNow } from '@/features/focus/hooks/use-now';
import { usePalette } from '@/features/focus/hooks/use-palette';
import { useFocusStore } from '@/features/focus/store/focus-store';
import type { SessionResult } from '@/features/focus/types/focus';
import { cn } from '@/lib/cn';
import { confirmDelete } from '@/lib/confirm';
import { timing } from '@/lib/motion';

const mascot = require('@/assets/images/art/mascot-meditate.png');
const mascotJoy = require('@/assets/images/art/mascot-joy.png');

const LENGTHS = [15, 25, 50];
const NAMES = ['Deep Work Session', 'Morning Focus', 'Project Work'];

export default function FocusScreen() {
  const router = useRouter();
  const active = useFocusStore((s) => s.active);
  const [result, setResult] = useState<SessionResult | null>(null);

  if (result) return <Finished result={result} onDone={() => router.back()} />;
  if (active) return <Running onFinish={setResult} onClose={() => router.back()} />;
  return <Setup onClose={() => router.back()} />;
}

function CloseButton({ onPress, label }: { onPress: () => void; label: string }) {
  const palette = usePalette();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      hitSlop={10}
      onPress={onPress}
      className="size-9 items-center justify-center rounded-full border border-border bg-surface">
      <Glyph name={{ ios: 'xmark', android: 'close' }} size={14} color={palette.foreground} />
    </Pressable>
  );
}

function Chip({ label, on, onPress }: { label: string; on: boolean; onPress: () => void }) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected: on }}
      onPress={onPress}
      className={cn('rounded-full border px-4 py-2', on ? 'border-accent bg-iris-deep' : 'border-border bg-surface')}>
      <Text className={cn('text-sm font-medium', on ? 'text-foreground' : 'text-muted')}>{label}</Text>
    </Pressable>
  );
}

function Setup({ onClose }: { onClose: () => void }) {
  const palette = usePalette();
  const startSession = useFocusStore((s) => s.startSession);
  const [minutes, setMinutes] = useState(25);
  const [name, setName] = useState(NAMES[0]);

  return (
    <View className="flex-1 bg-background px-5 pt-safe-offset-2 pb-safe-offset-4 gap-6">
      <View className="flex-row justify-end">
        <CloseButton label="Close" onPress={onClose} />
      </View>
      <View className="flex-1 items-center justify-center gap-6">
        <View className="items-center justify-center">
          <View className="absolute">
            <Glow size={300} opacity={0.4} />
          </View>
          <Image source={mascot} className="w-48 h-40" contentFit="contain" />
        </View>
        <View className="items-center gap-1.5">
          <Text className="text-2xl font-bold text-foreground">Ready to focus?</Text>
          <Text className="text-center text-sm text-muted">
            Shorts and Reels stay blocked while the timer runs.
          </Text>
        </View>
        <View className="items-center gap-2">
          <Text className="text-[10px] font-semibold tracking-widest text-muted">LENGTH</Text>
          <View className="flex-row gap-2">
            {LENGTHS.map((m) => (
              <Chip key={m} label={`${m} min`} on={m === minutes} onPress={() => setMinutes(m)} />
            ))}
          </View>
        </View>
        <View className="items-center gap-2">
          <Text className="text-[10px] font-semibold tracking-widest text-muted">SESSION</Text>
          <View className="flex-row flex-wrap justify-center gap-2">
            {NAMES.map((n) => (
              <Chip key={n} label={n} on={n === name} onPress={() => setName(n)} />
            ))}
          </View>
        </View>
      </View>
      <Pressable
        accessibilityRole="button"
        onPress={() => startSession(name, minutes)}
        className="flex-row items-center justify-center gap-2 rounded-2xl bg-accent py-4">
        <Glyph name={{ ios: 'play.fill', android: 'play_arrow' }} size={14} color={palette.foreground} />
        <Text className="text-base font-semibold text-accent-foreground">{`Start ${minutes} min focus`}</Text>
      </Pressable>
    </View>
  );
}

function Running({ onFinish, onClose }: { onFinish: (r: SessionResult) => void; onClose: () => void }) {
  const active = useFocusStore((s) => s.active);
  const finishSession = useFocusStore((s) => s.finishSession);
  const now = useNow(1000);
  const total = (active?.minutes ?? 0) * 60;
  const elapsed = active ? Math.floor((now - active.startedAt) / 1000) : 0;
  const left = Math.max(0, total - elapsed);
  const done = active !== null && left === 0;

  useEffect(() => {
    if (!done) return;
    const r = finishSession(true);
    if (r) onFinish(r);
  }, [done, finishSession, onFinish]);

  if (!active) return null;
  const mm = Math.floor(left / 60);
  const ss = `${left % 60}`.padStart(2, '0');

  const end = () =>
    confirmDelete({
      title: 'End this session?',
      message:
        elapsed < 60
          ? "Less than a minute in, so it won't be counted."
          : `You've focused for ${Math.floor(elapsed / 60)} min. That still counts toward your day.`,
      confirmLabel: 'End session',
      onConfirm: () => {
        const r = finishSession(false);
        if (r) {
          onFinish(r);
          return;
        }
        onClose();
      },
    });

  return (
    <View className="flex-1 bg-background px-5 pt-safe-offset-2 pb-safe-offset-4 gap-6">
      <View className="flex-row items-center justify-between">
        <Text className="text-[10px] font-semibold tracking-widest text-muted">FOCUSING</Text>
        <CloseButton label="Minimize" onPress={onClose} />
      </View>
      <View className="flex-1 items-center justify-center gap-8">
        <View className="items-center justify-center">
          <View className="absolute">
            <Glow size={340} opacity={0.35} />
          </View>
          <ScoreRing size={260} stroke={12} progress={total ? elapsed / total : 0} animate={false}>
            <Image source={mascot} className="w-28 h-24" contentFit="contain" />
            <Text className="text-5xl font-bold text-foreground" style={{ fontVariant: ['tabular-nums'] }}>
              {`${mm}:${ss}`}
            </Text>
            <Text className="text-xs text-muted">{`of ${active.minutes} min`}</Text>
          </ScoreRing>
        </View>
        <View className="items-center gap-1">
          <Text className="text-lg font-semibold text-foreground">{active.name}</Text>
          <Text className="text-sm text-lilac">Shorts and Reels are blocked. Stay with it.</Text>
        </View>
      </View>
      <Pressable
        accessibilityRole="button"
        onPress={end}
        className="items-center justify-center rounded-full border border-border bg-surface py-4">
        <Text className="text-base font-semibold text-ember">End session</Text>
      </Pressable>
    </View>
  );
}

function Finished({ result, onDone }: { result: SessionResult; onDone: () => void }) {
  const lift = useSharedValue(0);
  const glow = useSharedValue(0);
  const stamp = useSharedValue(0);

  useEffect(() => {
    Presets.System.notificationSuccess();
    lift.set(withTiming(-14, timing.draw));
    glow.set(withTiming(1, timing.draw));
    stamp.set(withDelay(350, withTiming(1, timing.enter)));
  }, [lift, glow, stamp]);

  const mascotStyle = useAnimatedStyle(() => ({ transform: [{ translateY: lift.get() }] }));
  const glowStyle = useAnimatedStyle(() => ({ opacity: 0.3 + glow.get() * 0.7, transform: [{ scale: 0.85 + glow.get() * 0.2 }] }));
  const stampStyle = useAnimatedStyle(() => ({ opacity: stamp.get(), transform: [{ scale: 1.15 - stamp.get() * 0.15 }] }));

  return (
    <View className="flex-1 bg-background px-5 pt-safe-offset-2 pb-safe-offset-4 gap-6">
      <View className="flex-1 items-center justify-center gap-8">
        <View className="items-center justify-center">
          <Animated.View style={glowStyle} className="absolute">
            <Glow size={360} opacity={0.55} />
          </Animated.View>
          <ScoreRing size={260} stroke={12} progress={1}>
            <Animated.View style={mascotStyle}>
              <Image source={result.completed ? mascotJoy : mascot} className="w-40 h-36" contentFit="contain" />
            </Animated.View>
          </ScoreRing>
        </View>
        <Animated.View style={stampStyle} className="items-center gap-2">
          <View className="rounded-full border border-accent bg-iris-deep px-4 py-2">
            <Text className="text-sm font-semibold text-foreground">
              {`${result.completed ? 'Session complete' : 'Session saved'} · +${result.minutes} min focused`}
            </Text>
          </View>
          <Text className="text-2xl font-bold text-foreground">{result.completed ? 'Beautifully done.' : 'Every minute counts.'}</Text>
          <Text className="text-center text-sm text-muted">{result.name}</Text>
          {result.newMilestone ? (
            <View className="flex-row items-center gap-1.5 pt-1">
              <Text className="text-sm">🔥</Text>
              <Text className="text-sm font-semibold text-lilac">{`${result.streak} day streak!`}</Text>
            </View>
          ) : (
            <Text className="text-sm text-lilac">{`${result.streak} day streak`}</Text>
          )}
        </Animated.View>
      </View>
      <Pressable accessibilityRole="button" onPress={onDone} className="items-center justify-center rounded-2xl bg-accent py-4">
        <Text className="text-base font-semibold text-accent-foreground">Done</Text>
      </Pressable>
    </View>
  );
}
