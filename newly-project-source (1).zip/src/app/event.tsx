import { useLocalSearchParams, useRouter } from 'expo-router';
import { Text, View } from 'react-native';

import { eventSubtitle, eventTitle } from '@/features/focus/components/activity-row';
import { IconTile } from '@/features/focus/components/icon-tile';
import { PlatformLogo } from '@/features/focus/components/platform-logo';
import { PrimaryButton, SheetBody, SheetTitle } from '@/features/focus/components/sheet-parts';
import { useFocusStore } from '@/features/focus/store/focus-store';
import { formatWhen } from '@/features/focus/utils/dates';

function Fact({ label, value }: { label: string; value: string }) {
  return (
    <View className="flex-1 gap-0.5 rounded-xl border border-border bg-surface-secondary px-4 py-3">
      <Text className="text-[11px] text-muted">{label}</Text>
      <Text className="text-base font-bold text-foreground">{value}</Text>
    </View>
  );
}

export default function EventSheet() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const event = useFocusStore((s) => s.events.find((e) => e.id === id));

  if (!event) {
    return (
      <SheetBody>
        <SheetTitle title="Not found" subtitle="This activity is no longer available." />
        <PrimaryButton label="Close" onPress={() => router.back()} />
      </SheetBody>
    );
  }

  const left =
    event.kind === 'block' ? (
      <PlatformLogo platform={event.platform} />
    ) : (
      <IconTile
        tone="soft"
        name={event.kind === 'milestone' ? { ios: 'flame.fill', android: 'local_fire_department' } : { ios: 'timer', android: 'timer' }}
      />
    );

  return (
    <SheetBody>
      <SheetTitle title={eventTitle(event)} subtitle={formatWhen(event.at, Date.now())} left={left} />
      <Text className="text-sm text-muted">
        {event.kind === 'block'
          ? `FocusFlow stopped this during ${event.session}. That's ${event.videos} short videos you didn't scroll through.`
          : eventSubtitle(event)}
      </Text>
      {event.kind === 'block' ? (
        <View className="flex-row gap-3">
          <Fact label="Time prevented" value={`${event.minutes} min`} />
          <Fact label="Videos skipped" value={`${event.videos}`} />
        </View>
      ) : null}
      {event.kind === 'session' ? (
        <View className="flex-row gap-3">
          <Fact label="Focused" value={`${event.minutes} min`} />
          <Fact label="Result" value={event.completed ? 'Completed' : 'Ended early'} />
        </View>
      ) : null}
      {event.kind === 'milestone' ? (
        <View className="flex-row gap-3">
          <Fact label="Streak" value={`${event.days} days`} />
        </View>
      ) : null}
      <PrimaryButton label="Done" onPress={() => router.back()} />
    </SheetBody>
  );
}
