# Designs

Every set of home-screen designs the user was shown in this project's chats, oldest first, kept here by Newly.
design/home.jpg and the tab pictures beside it are the look the app was last built from.
To bring an earlier look back, build from its pictures below; for new looks, call show_designs.

## Set 1 · 2026-11-11 · picked Midnight Minimal, built
Brief: FocusFlow is a mobile companion app for the Chrome extension that helps you manage your digital distractions on the go. It allows you to monitor your blocked short-form content stats, configure blocking rules, and view productivity streaks. The home screen features your daily focus score, quick toggles for YouTube Shorts and Instagram Reels blocking, and a summary of saved hours.
1. Midnight Minimal (picked): A sleek dark-mode aesthetic with OLED black backgrounds, subtle violet glowing accents, and clean sans-serif typography for maximum focus.. design/sets/2026-11-11-1/1-midnight-minimal.jpg
2. Clean Utility: A crisp light-mode look utilizing bright white spaces, cobalt blue functional elements, and structured card layouts for high readability.. design/sets/2026-11-11-1/2-clean-utility.jpg
3. Warm Focus: An editorial warm-toned direction featuring terracotta hues, soft cream cards, and serif headers that bring a calm, mindful feel to productivity.. design/sets/2026-11-11-1/3-warm-focus.jpg
4. Vibrant Play: A playful and energetic style using gradient mint-to-teal backgrounds, rounded pill buttons, and bouncy iconography to make blocking distractions fun.. design/sets/2026-11-11-1/4-vibrant-play.jpg
Tabs of the pick: Stats design/sets/2026-11-11-1/tab-stats.jpg, Rules design/sets/2026-11-11-1/tab-rules.jpg, Activity design/sets/2026-11-11-1/tab-activity.jpg
