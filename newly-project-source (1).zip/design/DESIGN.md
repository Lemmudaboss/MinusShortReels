# FocusFlow — design plan

**Subject:** reclaiming attention from short-form video. **Who:** students and makers who lose
evenings to Shorts and Reels. **Core action:** start a focus session (and tick the day's tasks).
**Moment of use:** at a desk, phone face up, glancing at it between work blocks — often at night.

## Directions considered
1. *Night sky* — near-black navy, violet glow, a soft meditating mascot, SF Pro. (picked by the user)
2. *Paper planner* — off-white, ink black, red-pencil marks. Lost: the user picked the dark design.
3. *Terminal* — mono type, green on black. Lost: too cold for a calm habit app.

## Palette (tokens in src/global.css, dark theme forced)
| name        | hex       | token                |
| ----------- | --------- | -------------------- |
| Midnight    | `#06060F` | background           |
| Deep ink    | `#0E0F22` | surface              |
| Night line  | `#1F2042` | border / separator   |
| Iris        | `#7A4CFF` | accent               |
| Lilac       | `#A28BFF` | link / delta text    |
| Mist        | `#9C9DC0` | muted                |
| Ember       | `#FF5468` | danger ("Blocked")   |

## Type
SF Pro throughout; small and tight as measured from the pictures: section heads 20 pt semibold,
row titles 14 pt, secondary 11–12 pt, big numbers 26–34 pt bold, page titles 34 pt bold.

## Imagery
The plum-violet mascot cut from the user's pictures (meditating, cheering, waving, with a shield),
glow-feathered so it sits on the dark cards; real platform logos as rounded squares.

## Shell
```
┌──────────────────────────────┐
│ ring 92  Focus Score  (i)     │  ← violet glow, content scrolls under bar
│ [mascot | Today's focus  ▶]   │
│ ...cards...                   │
│ ╭ Home  Stats  Rules  Activity╮│  ← native liquid-glass tab bar
└──────────────────────────────┘
```
Home (kept): ring header → focus card → blocking toggles → week bars → tasks → recent activity.
Alt drawn: focus card first with the ring inside it — lost, the picture leads with the score.

## Signature moment
Finishing a focus session: the countdown ring closes, the mascot lifts and glows, a
"Session complete · +25 min focused" stamp settles in, success haptic. Ticking a task fills its
circle with Iris and the check draws in. A new day of streak fires one celebration on Activity.

## Motion dial
standard — timing tokens only.

**Unmistakable:** a glowing violet monk-mascot keeping watch over your scroll habit.
