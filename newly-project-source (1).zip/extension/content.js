/**
 * FocusFlow shared content-script helpers.
 * Loaded before youtube-content.js / instagram-content.js on matching pages and
 * exposes one global, `FocusFlow`, with:
 *   - settings loading + live updates (popup message and storage changes)
 *   - a toggleable <style> tag for CSS-based hiding
 *   - a debounced MutationObserver helper
 *   - SPA URL-change detection
 *   - the full-page "Blocked by FocusFlow" screen
 */

(() => {
  if (window.FocusFlow) return;

  const DEFAULTS = { blockYouTube: true, blockInstagram: true, strictMode: false, lockUntil: 0 };
  const listeners = [];
  let settings = { ...DEFAULTS };

  let lockTimer = null;

  /** While Lock blocking runs, Shorts and Reels are blocked whatever the switches say. */
  function effective() {
    if (Date.now() >= (settings.lockUntil || 0)) return settings;
    return { ...settings, blockYouTube: true, blockInstagram: true };
  }

  /** Calls every registered handler with the latest settings. */
  function emit() {
    clearTimeout(lockTimer);
    const left = (settings.lockUntil || 0) - Date.now();
    if (left > 0) lockTimer = setTimeout(emit, left + 500); // re-apply when the lock ends
    const current = effective();
    for (const fn of listeners) {
      try {
        fn(current);
      } catch (err) {
        console.warn('[FocusFlow]', err);
      }
    }
  }

  /** Register a handler; it runs now (once settings load) and on every change. */
  function onSettings(fn) {
    listeners.push(fn);
  }

  chrome.storage.sync.get(DEFAULTS).then((stored) => {
    settings = { ...DEFAULTS, ...stored };
    emit();
  });

  // Instant update from the popup.
  chrome.runtime.onMessage.addListener((message) => {
    if (message && message.type === 'FOCUSFLOW_SETTINGS') {
      settings = { ...DEFAULTS, ...message.settings };
      emit();
    }
  });

  // Fallback: another device or window changed the synced settings.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync') return;
    for (const [key, { newValue }] of Object.entries(changes)) {
      if (key in DEFAULTS) settings[key] = newValue;
    }
    emit();
  });

  /** A <style> tag whose CSS can be switched on/off without re-creating it. */
  function createStyle(id, css) {
    let el = null;
    return function setEnabled(enabled) {
      if (enabled && !el) {
        el = document.createElement('style');
        el.id = id;
        el.textContent = css;
        (document.head || document.documentElement).appendChild(el);
      } else if (!enabled && el) {
        el.remove();
        el = null;
      }
    };
  }

  /** Observe DOM changes and run `fn` at most once per animation frame. */
  function observe(fn) {
    let queued = false;
    const run = () => {
      queued = false;
      fn();
    };
    const observer = new MutationObserver(() => {
      if (queued) return;
      queued = true;
      requestAnimationFrame(run);
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    return observer;
  }

  /** Calls `fn(url)` whenever the single-page app changes the URL. */
  function onUrlChange(fn) {
    let last = location.href;
    const check = () => {
      if (location.href === last) return;
      last = location.href;
      fn(location.href);
    };
    window.addEventListener('popstate', check);
    window.addEventListener('yt-navigate-finish', check);
    setInterval(check, 500);
  }

  /** Mark an element hidden by FocusFlow so it can be restored later. */
  function hide(el) {
    if (!el || el.dataset.focusflowHidden) return;
    el.dataset.focusflowHidden = '1';
    el.style.setProperty('display', 'none', 'important');
  }

  /** Restore everything FocusFlow hid (used when a toggle is turned off). */
  function unhideAll() {
    document.querySelectorAll('[data-focusflow-hidden]').forEach((el) => {
      el.style.removeProperty('display');
      delete el.dataset.focusflowHidden;
    });
  }

  let pauseTimer = null;

  /** Covers the page with the "Blocked by FocusFlow" screen and keeps media paused. */
  function showBlockScreen({ platform, homeURL }) {
    if (document.getElementById('focusflow-block')) return;

    const overlay = document.createElement('div');
    overlay.id = 'focusflow-block';
    overlay.innerHTML = `
      <style>
        #focusflow-block{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;
          background:radial-gradient(120% 70% at 50% 0%,#1b1450 0%,#06060f 70%);color:#f2f1fa;
          font:14px/1.4 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif}
        #focusflow-block .ff-card{max-width:360px;padding:32px 28px;text-align:center;background:#0d0e21;
          border:1px solid #1f2042;border-radius:24px;box-shadow:0 20px 60px rgba(0,0,0,.5)}
        #focusflow-block .ff-icon{width:56px;height:56px;margin:0 auto 16px;border-radius:16px;display:grid;place-items:center;
          background:linear-gradient(145deg,#7a4cff,#5130c9);font-size:26px}
        #focusflow-block h2{margin:0 0 6px;font-size:20px}
        #focusflow-block p{margin:0 0 20px;color:#9c9dc0}
        #focusflow-block a{display:inline-block;padding:10px 20px;border-radius:999px;background:#7a4cff;color:#fff;
          text-decoration:none;font-weight:600}
      </style>
      <div class="ff-card" role="alertdialog" aria-label="Blocked by FocusFlow">
        <div class="ff-icon">🛡️</div>
        <h2>Blocked by FocusFlow</h2>
        <p>${platform} is blocked so you can focus on what matters.</p>
        <a href="${homeURL}">Back to ${platform === 'YouTube Shorts' ? 'YouTube' : 'Instagram'}</a>
      </div>`;
    document.documentElement.appendChild(overlay);

    // Short-form players autoplay with sound; keep them silent behind the overlay.
    pauseTimer = setInterval(() => {
      document.querySelectorAll('video').forEach((v) => {
        if (!v.paused) v.pause();
        v.muted = true;
      });
    }, 300);
  }

  function hideBlockScreen() {
    document.getElementById('focusflow-block')?.remove();
    if (pauseTimer) clearInterval(pauseTimer);
    pauseTimer = null;
  }

  window.FocusFlow = {
    get settings() {
      return effective();
    },
    onSettings,
    createStyle,
    observe,
    onUrlChange,
    hide,
    unhideAll,
    showBlockScreen,
    hideBlockScreen,
  };
})();
