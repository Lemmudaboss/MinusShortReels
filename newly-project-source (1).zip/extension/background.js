/**
 * FocusFlow background service worker.
 * - Writes the default settings on first install (keeps any the user already has).
 * - Shows a small badge on the toolbar icon while blocking is on.
 * - Answers "get settings" requests from content scripts.
 * - Enforces Lock blocking: while `lockUntil` is in the future, any change that
 *   turns blocking off or shortens the lock is put straight back.
 */

const DEFAULTS = { blockYouTube: true, blockInstagram: true, strictMode: false, lockUntil: 0 };
const PROTECTED = ['blockYouTube', 'blockInstagram', 'strictMode'];
const ALARM = 'focusflow-lock-end';

async function getSettings() {
  return chrome.storage.sync.get(DEFAULTS);
}

async function updateBadge() {
  const s = await getSettings();
  const active = s.blockYouTube || s.blockInstagram;
  const locked = Date.now() < s.lockUntil;
  await chrome.action.setBadgeText({ text: active ? (locked ? 'LOCK' : s.strictMode ? 'STR' : 'ON') : '' });
  await chrome.action.setBadgeBackgroundColor({ color: '#7a4cff' });
}

/** Schedules a badge refresh for when the lock ends. */
async function scheduleLockEnd() {
  const { lockUntil } = await getSettings();
  await chrome.alarms.clear(ALARM);
  if (Date.now() < lockUntil) chrome.alarms.create(ALARM, { when: lockUntil + 1000 });
}

chrome.runtime.onInstalled.addListener(async () => {
  const current = await chrome.storage.sync.get(null);
  const missing = {};
  for (const [key, value] of Object.entries(DEFAULTS)) {
    if (!(key in current)) missing[key] = value;
  }
  if (Object.keys(missing).length) await chrome.storage.sync.set(missing);
  updateBadge();
  scheduleLockEnd();
});

chrome.runtime.onStartup.addListener(() => {
  updateBadge();
  scheduleLockEnd();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM) updateBadge();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'sync') return;

  // The lock that was running before this change (a shortened lockUntil doesn't count).
  const lockBefore = changes.lockUntil ? changes.lockUntil.oldValue || 0 : null;
  chrome.storage.sync.get(DEFAULTS).then((now) => {
    const lockedUntil = Math.max(now.lockUntil, lockBefore ?? 0);
    if (Date.now() >= lockedUntil) {
      updateBadge();
      scheduleLockEnd();
      return;
    }

    const revert = {};
    if (lockBefore !== null && now.lockUntil < lockBefore) revert.lockUntil = lockBefore;
    for (const key of PROTECTED) {
      const change = changes[key];
      if (change && change.oldValue === true && change.newValue !== true) revert[key] = true;
    }

    if (Object.keys(revert).length) {
      chrome.storage.sync.set(revert); // triggers onChanged again, which then finds nothing to revert
      return;
    }
    updateBadge();
    scheduleLockEnd();
  });
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message && message.type === 'FOCUSFLOW_GET_SETTINGS') {
    getSettings().then(sendResponse);
    return true; // keep the channel open for the async reply
  }
  return false;
});
