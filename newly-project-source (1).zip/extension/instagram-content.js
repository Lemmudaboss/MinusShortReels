/**
 * FocusFlow for Instagram.
 * - Hides every link to Reels (nav tab, profile Reels tab, grid items) and the reels trays.
 * - On instagram.com/reels/* or /reel/*: Strict Mode redirects home, otherwise a block screen appears.
 */

(() => {
  const FF = window.FocusFlow;
  if (!FF) return;

  const HOME = 'https://www.instagram.com/';

  const setCSS = FF.createStyle(
    'focusflow-instagram',
    `
    a[href*="/reels/"],
    a[href^="/reel/"],
    a[href*="instagram.com/reel/"],
    [aria-label*="reels tray" i],
    div[role="tablist"] a[href$="/reels/"] {
      display: none !important;
    }
  `,
  );

  const isReelsURL = (url = location.href) => /^\/(reels?)\//.test(new URL(url).pathname);

  /** Hides reels trays and feed posts that are Reels. Runs on every DOM change. */
  function sweep() {
    // Feed posts / suggestions whose main link is a Reel.
    document.querySelectorAll('article a[href^="/reel/"]').forEach((link) => FF.hide(link.closest('article')));

    // Horizontal reels trays: a list whose items are all Reel links.
    document.querySelectorAll('ul').forEach((list) => {
      const items = list.querySelectorAll(':scope > li');
      if (items.length < 2) return;
      const allReels = [...items].every((li) => li.querySelector('a[href^="/reel/"]'));
      if (allReels) FF.hide(list.closest('section, div') || list);
    });
  }

  function guardPage(settings) {
    if (!settings.blockInstagram || !isReelsURL()) {
      FF.hideBlockScreen();
      return;
    }
    if (settings.strictMode) {
      location.replace(HOME);
      return;
    }
    FF.showBlockScreen({ platform: 'Instagram Reels', homeURL: HOME });
  }

  let observer = null;

  function apply(settings) {
    setCSS(settings.blockInstagram);

    if (settings.blockInstagram && !observer) {
      observer = FF.observe(sweep);
      sweep();
    } else if (!settings.blockInstagram && observer) {
      observer.disconnect();
      observer = null;
      FF.unhideAll();
    }

    guardPage(settings);
  }

  FF.onSettings(apply);
  FF.onUrlChange(() => guardPage(FF.settings));
})();
