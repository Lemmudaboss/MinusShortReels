/**
 * FocusFlow for YouTube.
 * - CSS hides the Shorts shelves and sidebar entries the moment the page paints.
 * - A MutationObserver catches what CSS can't select (sidebar entries by title,
 *   video renderers whose link points to /shorts/) as YouTube lazily renders them.
 * - On youtube.com/shorts/*: Strict Mode redirects home, otherwise a block screen appears.
 */

(() => {
  const FF = window.FocusFlow;
  if (!FF) return;

  const HOME = 'https://www.youtube.com/';

  const setCSS = FF.createStyle(
    'focusflow-youtube',
    `
    ytd-reel-shelf-renderer,
    ytd-rich-shelf-renderer[is-shorts],
    ytd-rich-section-renderer:has(ytd-rich-shelf-renderer[is-shorts]),
    ytd-guide-entry-renderer:has(a[title="Shorts"]),
    ytd-mini-guide-entry-renderer[aria-label="Shorts"],
    ytd-mini-guide-entry-renderer:has(a[title="Shorts"]),
    yt-chip-cloud-chip-renderer:has([title="Shorts"]),
    ytd-video-renderer:has(a[href^="/shorts/"]),
    ytd-grid-video-renderer:has(a[href^="/shorts/"]),
    ytd-rich-item-renderer:has(a[href^="/shorts/"]),
    ytd-compact-video-renderer:has(a[href^="/shorts/"]),
    ytm-shorts-lockup-view-model,
    ytm-shorts-lockup-view-model-v2,
    grid-shelf-view-model:has(ytm-shorts-lockup-view-model),
    tp-yt-paper-tab:has([title="Shorts"]),
    yt-tab-shape[tab-title="Shorts"] {
      display: none !important;
    }
  `,
  );

  const isShortsURL = (url = location.href) => new URL(url).pathname.startsWith('/shorts/');

  /** Hides anything that is (or links to) Shorts. Runs on every DOM change. */
  function sweep() {
    // Sidebar + mini sidebar "Shorts" entries.
    document.querySelectorAll('ytd-guide-entry-renderer, ytd-mini-guide-entry-renderer').forEach((entry) => {
      const label = (entry.querySelector('a')?.getAttribute('title') || entry.textContent || '').trim();
      if (/^shorts$/i.test(label)) FF.hide(entry);
    });

    // Shelves.
    document
      .querySelectorAll('ytd-reel-shelf-renderer, ytd-rich-shelf-renderer[is-shorts]')
      .forEach((shelf) => FF.hide(shelf.closest('ytd-rich-section-renderer') || shelf));

    // Any video card that links to a Short.
    document.querySelectorAll('a[href^="/shorts/"]').forEach((link) => {
      const card = link.closest(
        'ytd-video-renderer, ytd-grid-video-renderer, ytd-rich-item-renderer, ytd-compact-video-renderer, ytm-shorts-lockup-view-model, ytm-shorts-lockup-view-model-v2',
      );
      if (card) FF.hide(card);
    });
  }

  /** Handles being on a /shorts/ URL: redirect (strict) or block screen. */
  function guardPage(settings) {
    if (!settings.blockYouTube || !isShortsURL()) {
      FF.hideBlockScreen();
      return;
    }
    if (settings.strictMode) {
      location.replace(HOME);
      return;
    }
    FF.showBlockScreen({ platform: 'YouTube Shorts', homeURL: HOME });
  }

  let observer = null;

  function apply(settings) {
    setCSS(settings.blockYouTube);

    if (settings.blockYouTube && !observer) {
      observer = FF.observe(sweep);
      sweep();
    } else if (!settings.blockYouTube && observer) {
      observer.disconnect();
      observer = null;
      FF.unhideAll();
    }

    guardPage(settings);
  }

  FF.onSettings(apply);
  FF.onUrlChange(() => guardPage(FF.settings));
})();
