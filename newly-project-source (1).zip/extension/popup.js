/**
 * FocusFlow popup.
 * Loads the saved settings into the three toggles, saves every change to
 * chrome.storage.sync, and tells open YouTube / Instagram tabs to re-apply.
 *
 * Lock blocking: picks a duration and stores `lockUntil` (a timestamp). Until
 * then, blocking can be turned on but never off, and the lock can only be
 * extended. The popup disables the switches; background.js enforces the same
 * rule on storage so the lock holds even if the popup is bypassed.
 */

const DEFAULTS = { blockYouTube: true, blockInstagram: true, strictMode: false, lockUntil: 0 };
const TOGGLES = ['blockYouTube', 'blockInstagram', 'strictMode'];

const statusEl = document.getElementById('status');
const footerEl = document.getElementById('footer');
const lockCard = document.getElementById('lockCard');
const lockTitle = document.getElementById('lockTitle');
const lockHint = document.getElementById('lockHint');
const lockMinutes = document.getElementById('lockMinutes');
const lockButton = document.getElementById('lockButton');

let settings = { ...DEFAULTS };

const isLocked = () => Date.now() < (settings.lockUntil || 0);

/** "3:45 PM", or "tomorrow, 3:45 PM" when the lock ends on another day. */
function formatEnd(ms) {
  const end = new Date(ms);
  const time = end.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  return end.toDateString() === new Date().toDateString() ? time : `tomorrow, ${time}`;
}

/** "1h 12m left". */
function formatLeft(ms) {
  const minutes = Math.max(1, Math.ceil((ms - Date.now()) / 60000));
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${h ? `${h}h ` : ''}${m}m left`;
}

/** Shows "Active", "Locked" or "Paused" in the header. */
function renderStatus() {
  const active = settings.blockYouTube || settings.blockInstagram;
  statusEl.textContent = isLocked() ? 'Locked' : active ? 'Active' : 'Paused';
  statusEl.classList.toggle('off', !active);
}

/** Disables the switches that the lock is holding on, and updates the lock card. */
function renderLock() {
  const locked = isLocked();
  for (const key of TOGGLES) {
    const input = document.getElementById(key);
    input.checked = Boolean(settings[key]);
    // While locked, an "on" switch can't be turned off; an "off" one can still be turned on.
    const held = locked && input.checked;
    input.disabled = held;
    input.closest('.row').classList.toggle('locked', held);
  }

  lockCard.classList.toggle('active', locked);
  if (locked) {
    lockTitle.textContent = `Locked until ${formatEnd(settings.lockUntil)}`;
    lockHint.textContent = `${formatLeft(settings.lockUntil)} · no turning it off early`;
    lockButton.textContent = 'Add time';
  } else {
    lockTitle.textContent = 'Lock blocking';
    lockHint.textContent = "Can't be turned off until the time is up";
    lockButton.textContent = 'Lock';
  }
  renderStatus();
}

/** Sends the new settings to every open YouTube / Instagram tab (and the active tab). */
async function broadcast() {
  const message = { type: 'FOCUSFLOW_SETTINGS', settings };
  const tabs = await chrome.tabs.query({ url: ['*://*.youtube.com/*', '*://*.instagram.com/*'] });
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  const ids = new Set(tabs.map((t) => t.id));
  if (active && active.id !== undefined) ids.add(active.id);

  for (const id of ids) {
    // A tab without our content script (e.g. chrome:// pages) rejects; that's fine.
    chrome.tabs.sendMessage(id, message).catch(() => {});
  }
}

async function save(patch, note) {
  Object.assign(settings, patch);
  await chrome.storage.sync.set(patch);
  renderLock();
  await broadcast();
  footerEl.textContent = note;
}

/** Starts a lock, or extends the running one. Locking turns Shorts and Reels blocking on. */
async function lock() {
  const minutes = Number(lockMinutes.value);
  const from = isLocked() ? settings.lockUntil : Date.now();
  const until = from + minutes * 60000;
  const ok = window.confirm(
    `Lock blocking until ${formatEnd(until)}?\n\nYouTube Shorts and Instagram Reels stay blocked until then. You can't turn them off or end the lock early.`,
  );
  if (!ok) return;
  await save({ lockUntil: until, blockYouTube: true, blockInstagram: true }, `Locked until ${formatEnd(until)}.`);
}

async function init() {
  settings = await chrome.storage.sync.get(DEFAULTS);
  renderLock();

  for (const key of TOGGLES) {
    const input = document.getElementById(key);
    input.addEventListener('change', async () => {
      if (isLocked() && !input.checked) {
        input.checked = true; // the lock holds; this can't be turned off
        return;
      }
      await save({ [key]: input.checked }, 'Saved. Open tabs updated.');
    });
  }

  lockButton.addEventListener('click', lock);

  // Keep the countdown fresh and release the switches the moment the lock ends.
  setInterval(renderLock, 15000);
}

init();
